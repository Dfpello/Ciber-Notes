Las siguientes herramientas son algunas de las cuales sirven para reconocer las IP que hay en nuestra red y saber a cual atacar

**Arp-scan**
```bash
arp-scan -I eth0 --localnet
```
![[Pasted image 20240227160301.png]]

**Netdiscover**
```bash
netdiscover -i eth0 -r 192.168.0.0/24
```
![[Pasted image 20240227160616.png]]

**Nmap**
```bash
nmap -sn 192.168.0.0/24
```
![[Pasted image 20240227160732.png]]
