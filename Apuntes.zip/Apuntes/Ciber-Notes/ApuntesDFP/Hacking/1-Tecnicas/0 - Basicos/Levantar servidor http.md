
Esto lo usamos para la transferencia de archivos con el objetivo de obtener una reverse shell o enviar archivos para la escalada de privilegios entre otras cosas
```bash
python3 -m http.server 80
```