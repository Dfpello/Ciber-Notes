Esto es para conseguir una shell en bash y así estabilizamos el acceso a la máquina
Esto lo logramos mediante los siguientes comandos
```shell
script /dev/null -c bash
^Z
stty raw -echo; fg
reset xterm
export TERM=xterm
export SHELL=bash
```