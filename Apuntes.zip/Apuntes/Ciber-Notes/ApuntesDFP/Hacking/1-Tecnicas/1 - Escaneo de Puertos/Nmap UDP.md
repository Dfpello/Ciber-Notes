
Pese a que lo mas común sea hacer el protocola TCP hay maquinas que emplean el protocolo UDP y para ello también usaremos nmap con el siguiente comando
```bash
nmap -sU --top-ports 200 --min-rate=5000 -Pn 192.168.0.17
```
1. -sU
	1. Esto indica que el escaneo va a ser por UDP
2. --top-ports 200
	1. Abarca los 200 puertos mas comunes