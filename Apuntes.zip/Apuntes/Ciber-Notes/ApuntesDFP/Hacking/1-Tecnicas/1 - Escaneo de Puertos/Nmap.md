
Usaremos nmap para el escaneo de puertos 
```bash
nmap -sn 192.168.0.0/24
```
Esto lo usamos para escanear ver que dispositivos están conectados
![[Pasted image 20240227160732.png]]
```bash
nmap -p- --open -sS -sV -sC -sS -vvv -n -Pn 192.168.1.74 -oN escaneo 
```
1. -p- --open
	1. Abarca todos los puertos abiertos
2. -sS -sC -sV
	1. Scripts para el reconocimiento y version del reconocimiento
3. -n
	1. Para que no haga la resolucion dns
4. --min-rate=5000 o 2000
	1. La velocidad del escaneo en entornos reales se recomienda usar 2000 y en entornos controlados 5000 debido a que es mas rápido
5. -vvv
	1. Para que vaya enviando los resultados sobre la marcha
6. -Pn
	1. Impide el ping ahorrando el problema de que la maquina objetivo tenga un firewall protegiéndola de esto
7. -oN escaneo.txt
	1. Se guarda en un archivo con nombre escaneo.txt
![[Pasted image 20240227172537.png]]

Una vez escaneamos los puertos podemos ver si es vulnerable a alguna de las vulnerabilidades mas comunes (No es muy recomendado en entornos reales debido a que hace mucho ruido) para ello usamos el comando que nos dará el CVE de la vulnerabilidad
```bash
nmap --script "vuln" -p 445 10.0.2.8 
```
1. --script "vuln"
	1. En este caso usamos el script vuln para atacar a la máquina víctima
2. -p
	1. Puerto al que dirigimos el ataque
![[Pasted image 20240227173600.png]]