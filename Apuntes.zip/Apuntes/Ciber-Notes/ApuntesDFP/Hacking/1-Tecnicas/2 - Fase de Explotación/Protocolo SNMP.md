
Este protocolo tiene la peculiaridad de que corre por udp y se usa para obtener información de la máquina víctima.

```bash
onesixtyone -c /usr/share/wordlists/rockyou.txt 10.0.2.21
snmpwalk -v 2c -c security 10.0.2.21
```
Usaremos la herramienta de onesixtyone para que nos encuentre la clave de comunidad que nos permitirá seguir enumerando este protocolo![[Pasted image 20240307231332.png]]
Ahora con la clave de seguridad security usamos snmpwalk para que nos enumere información
![[Pasted image 20240307231432.png]]
