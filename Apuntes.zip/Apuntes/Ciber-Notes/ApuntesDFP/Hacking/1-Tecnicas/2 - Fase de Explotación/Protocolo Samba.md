
Para explotar este protocolo usaremos la herramienta de rpcclient para enumerar usuarios y posteriormente haremos un ataque de fuerza bruta contra el protocolo SMB dado el usuario capturado 
```rpcclient
srvinfo
querydispinfo
enumdomusers
```
1. srvinfo
	1. Proporciona información del usuario capturado
2. querydispinfo
	1. Para conseguir los usuarios de la máquina
3. enumdomusers
	1. Enumera los usuarios

![[Pasted image 20240307213450.png]]

