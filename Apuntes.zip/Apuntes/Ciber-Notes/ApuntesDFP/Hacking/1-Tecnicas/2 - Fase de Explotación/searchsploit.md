
Sirve para buscar exploits en una gran base de datos

```bash
searchsploit openssh 7.2 #Buscara exploits para la version 7.2 de ssh
```