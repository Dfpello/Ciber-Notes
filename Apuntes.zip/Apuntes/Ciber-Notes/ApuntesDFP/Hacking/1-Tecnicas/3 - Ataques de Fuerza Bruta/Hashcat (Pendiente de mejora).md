
Esta herramienta sirve para descifrar hashes siguiendo el siguiente protocolo.
Primero usaremos hash-identifier para ver los posibles hashes

```bash
hashcat -m 0 -a 0 hash.txt dic.txt
#El parametro -m identifica el modo de ataque 0 es para MD5
#
#El parametro -a identifica el tipo de ataque 0 es fuerza bruta
hashcat -m 3200 -a 3 Ej4.txt ?l?l?l?l
#usa el parametro 3 para hacer un ataque a mascara siendo la ?l?l?l?l cuatro letras en minusculas
```