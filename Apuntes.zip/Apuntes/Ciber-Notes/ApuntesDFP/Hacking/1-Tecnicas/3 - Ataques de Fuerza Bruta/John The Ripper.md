Esta herramienta se usa para crackear contraseñas en local
```shell
zip2john comprimido.zip > hash
keepass2john database.kdbx > hash
ssh2john id_rsa > hash
john --wordlist=/usr/share/wordlists/rockyou.txt hash
```

1. zip2john ...
	1. Saca el hash de archivos zip
2. keepass2john
	1. Saca el hash de archivos kdbx
3. john
	1. Esto es para crackear los hash
4. --wordlist=...
	1. Para definir el diccionario
5. --format=...
	1. Para definir el tipo de hash al que se enfrenta si necesitamos crackear un hash

**Saber el tipo de hash**
Para esto usaremos la herramienta de hash-identifier
