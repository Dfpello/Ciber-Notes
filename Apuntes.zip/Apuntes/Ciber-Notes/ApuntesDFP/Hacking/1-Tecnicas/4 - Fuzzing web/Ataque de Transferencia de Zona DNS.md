Este ataque se realiza cuando tenemos un servicio web de hosting y corriendo también un servicio DNS para ello usaremos la herramienta dig que nos proporcionara mucha información 

```bash
dig axfr hunterzone.nyx @10.0.2.14
```
1. axfr
	1. Este comando se utiliza para transferir toda la información de una zona DNS de un servidor a otro
2. hunterzone.nyx
	3. Es el nombre de la zona DNS desde la cual se desea realizar la transferencia
3. **@10.0.2.14**
	1. Indica la dirección IP del servidor DNS desde el cual se desea realizar la transferencia de zona