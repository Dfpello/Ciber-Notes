Esta herramienta hace una búsqueda recursiva dentro de la web aunque tiene el problema de que el diccionario por defecto es muy pequeño
```bash
dirb http://10.0.2.7/ #Busca directorios en una web
dirsearch -u http://10.0.2.7/ #Busca directorios en una web
```
