
Esta es una herramienta de fuzzing la cual deberíamos utilizar siempre que la maquina victima tenga directorios web
```bash
gobuster dir -u http://web.com -w dic.txt -x php,html -s 200 -o output.txt
gobuster dns -u http://web.com
```

1. dir
	1. Para enumerar directorios o subdominios respectivamente
2. dns
	3. Para enumerar subdominios respectivamente
3. -u
	1. Para indicar la url
4. -x
	1. Para especificar las extensiones de los archivos
5. -w
	1. Para indicar el lugar del diccionario
6. -s
	1. Para ajustar la velocidad
7. -o
	1. Para guardar los resultados