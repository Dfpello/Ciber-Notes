
```bash
wfuzz -c --hc=404 -w diccionario.txt -u http://web.com/FUZZ
wfuzz -c --hc=404 --hl=1 -w diccionario.txt -H "Host: FUZZ.web.com" -u 10.0.2.13
```
1. -c
	1. Colorea la salida para hacerla mas legible
2. --hc=404
	3. Imprime las salidas con un código distinto a 404
3. --hl=1
	1. Imprime las salidas con un número de líneas distinto a 1
4. -w diccionario.txt
	1. Indica la ubicación del diccionario
5. -H "Host: FUZZ.web.com"
	1. Saca la web a la que se le va a hacer el ataque cuando este es para los subdominios
6. -u
	1. Indica donde se va a atacar poniendo el FUZZ donde quieras usar el diccionario y  si es una búsqueda de subdominios será la IP de la máquina víctima
