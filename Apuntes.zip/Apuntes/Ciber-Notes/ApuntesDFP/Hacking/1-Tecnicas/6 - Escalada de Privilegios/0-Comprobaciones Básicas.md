
**1 - SUDO**
```bash
sudo -l
```
Mediante este comando se enumeran los bianrios que se pueden ejecutar para la escalada de privilegios que luego los buscamos gtfobins
**2 -  SUID**
```bash
find / -perm -4000 2>/dev/null
```
Enumeramos los SUID para ver si hay alguno que nos permita la escalada de privilegios .
**3 - Capabilities**
```bash
getcap -r / 2>/dev/null
```