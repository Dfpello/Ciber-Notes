```bash
getcap -r / 2>/dev/null
```