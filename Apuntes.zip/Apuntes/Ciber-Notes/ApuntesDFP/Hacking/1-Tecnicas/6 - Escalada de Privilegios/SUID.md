Enumeramos los SUID para ver si hay alguno que nos permita la escalada de privilegios mediante el siguiente comando.
```bash
find / -perm -4000 2>/dev/null
```