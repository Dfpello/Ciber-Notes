
Una de las principales maneras para escalar privilegios es ejecutar un sudo -l
```bash
sudo -l
```
Mediante este comando se enumeran los bianrios que se pueden ejecutar para la escalada de privilegios que luego los buscamos gtfobins