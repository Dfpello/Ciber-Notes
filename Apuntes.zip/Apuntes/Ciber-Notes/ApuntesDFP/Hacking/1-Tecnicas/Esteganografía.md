
La esteganografía consiste en encontrar archivos ocultos en imágenes para ello uso la herramienta de steghide para ello tenemos la herramienta de stegseek para crackear paraphrases y steghide si conocemos el paraphrase.

**steghide**
```bash
#Ocultar datos
steghide embed -ef archivo-secreto.txt -cf imagen.jpg -sf img.jpg -p pass
#-ef archivo a ocultar
#-cf imagen sobre la que se oculta
#-sf imagen con archivo oculto
#-p contraseña

#Sacar datos
steghide extract -sf img.jpg -p password
#-sf imagen a extraer
#-p la contraseña para extraerlo
```

**stegseek**
```shell
stegseek --crack cat-hidden.jpg /usr/share/wordlists/rockyou.txt out.txt
stegseek --seed cat-hidden.jpg seed.txt
```

1. --crack  secret.jpg     diccionario.txt     salida.txt
	1. Para crackear la contraseña de la imagen siguiendo el orden de arriba
2. --seed secret.jpg     salida.txt
	1. Para ver si la imagen tiene contenido oculto además de cuanto contenido oculto tiene y el algoritmo de encriptación