
tmux es un terminal optimizado, aquí voy a describir los comandos para su correcto uso
Usamos  Ctrl + b para los comandos de tmux seguido de algo a ejecutar:
Si luego ponemos c nos crea un nuevo terminal
Si luego ponemos % nos divide la pantalla en dos terminales verticales
Si luego ponemos " nos divide la pantalla en dos terminales horizontales