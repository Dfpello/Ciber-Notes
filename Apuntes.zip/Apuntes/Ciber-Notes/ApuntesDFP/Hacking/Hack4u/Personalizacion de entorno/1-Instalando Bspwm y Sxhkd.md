Primero ejecutamos el comando:
**apt install build-essential git vim xcb libxcb-util0-dev libxcb-ewmh-dev libxcb-randr0-dev libxcb-icccm4-dev libxcb-keysyms1-dev libxcb-xinerama0-dev libasound2-dev libxcb-xtest0-dev libxcb-shape0-dev**
Posteriormente ejecutamos:
- **git clone https://github.com/baskerville/bspwm.git**
- **git clone https://github.com/baskerville/sxhkd.git**

Y nos metemos en sus directorios y ejecutamos ‘**make**‘ y ‘**sudo make install**‘.

En caso de que os salga algún error relacionado con ‘**xinerama**‘, podéis ejecutar este comando:

- **sudo apt install libxinerama1 libxinerama-dev**

Finalmente, instalaremos ‘**bspwm**‘ con el comando ‘**sudo apt install bspwm**