Por aquí tenéis todo el comando necesario a ejecutar para instalar ciertas dependencias previas:

- **apt install meson libxext-dev libxcb1-dev libxcb-damage0-dev libxcb-xfixes0-dev libxcb-shape0-dev libxcb-render-util0-dev libxcb-render0-dev libxcb-composite0-dev libxcb-image0-dev libxcb-present-dev libxcb-xinerama0-dev libpixman-1-dev libdbus-1-dev libconfig-dev libgl1-mesa-dev libpcre2-dev libevdev-dev uthash-dev libev-dev libx11-xcb-dev libxcb-glx0-dev**

Posteriormente, os descargáis el picom a través del siguiente comando ejecutado en la carpeta de descargas:

- **git clone https://github.com/ibhagwan/picom.git**

Una vez hecho, nos metemos en el directorio creado y ejecutamos los siguientes comandos:

- **git submodule update –init –recursive** [Son 2 guiones donde pone ‘**init**‘ y ‘**recursive**‘]
- **meson –buildtype=release . build** [Son 2 guiones donde pone ‘**buildtype**‘] 
- **ninja -C build**
- **sudo ninja -C build install**

En esta clase también hemos instalado ‘**rofi**‘, lo hemos hecho mediante la ejecución del siguiente comando:

- **apt install rofi**

Con esto hecho, ya migramos a nuestro entorno ‘**bspwm**‘ y verificamos que todos los atajos estén funcionando correctamente.