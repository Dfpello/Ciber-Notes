
#### Bienvenido a la 9ª Edición de la HackersWeek
Flag: ctfhw9{c4r4mb4s1qu33r3sr4p1d@}
Miramos el código fuente de la web que nos proporcionan y vemos el siguiente apartado![[Pasted image 20231122121006.png]]
#### Cortocircuito
Flag: ctfhw9{hackwebdone}
Miramos en el directorio robots.txt en el que encontramos un Disallow: /9d153579e1bdb62ae769445738e8a5d5/ y al meternos en ese directorio encontramos la flag![[Pasted image 20231122124359.png]]
