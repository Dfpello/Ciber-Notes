

```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.29 -oN escaneo
ftp 10.0.2.29
cat .secretnote.txt
knock 10.0.2.29 1000 2000 3000
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos donde vemos que tiene únicamente el puerto 21 abierto.
![[Pasted image 20240310185707.png]]
Entramos como usario anonymous por el puerto 21 debido a la vulnerabilidad Anonymous ftp
y encontramos una nota secreta que nos descargamos en la máquina local.
```ftp
ls -la
get .secretnote.txt
exit
```
![[Pasted image 20240310190154.png]]
Ahora vemos la pista e investigamos lo que es el knock ports encontramos que es una técnica de ofuscación en la que si haces knock a ciertos puertos en cierta combinación se abre otro puerto dentro de la máquina