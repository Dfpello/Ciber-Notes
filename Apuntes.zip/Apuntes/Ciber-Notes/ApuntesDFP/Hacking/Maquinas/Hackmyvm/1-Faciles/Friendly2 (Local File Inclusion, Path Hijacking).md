
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.19 -oN escaneo
gobuster dir -u http://10.0.2.19/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
nano id_rsa #Metemos el texto
chmod 600 id_rsa
ssh2john id_rsa > hash
john --wordlist=/usr/share/wordlists/rockyou.txt hash
ssh -i id_rsa ghost@10.0.2.19
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 22 y 80![[Pasted image 20240305224055.png]]
Entramos al sitio web pero no hay gran cosa y revisando su codigo tampoco así que haremos fuzzing con gobuster y encontramos el directorio tools![[Pasted image 20240305224856.png]]
Y cuando entramos  vemos una pagina normal pero si vemos su codigo fuente encontramos un comentario extraño![[Pasted image 20240305224943.png]]
Debido a que hay un php haciendo algo en un html podemos estar en un local file inclusion así que vamos retrocediendo y ponemos el directorio /etc/passwd para ver los usuarios![[Pasted image 20240305225252.png]]
Vemos que hay un usuario gh0st e intentamos apuntar hacia su fichero id_rsa para entrar por ssh y encontramos el archivo![[Pasted image 20240305225443.png]]
![[Pasted image 20240305225455.png]]
Ahora copiaremos el rsa en un fichero id_rsa y accederemos por ssh al usuario gh0st pero nos pide un paraphrase así que usaremos john y veremos q esta es celtic![[Pasted image 20240305225957.png]]
Con esto entraríamos ya en la máquina por ssh y conseguiríamos la flag de usuario
![[Pasted image 20240305230119.png]]
```shell
cat user.txt
sudo -l
nano /opt/security.sh
cd /tmp
nano tr
chmod +x tr
sudo PATH=/tmp:$PATH /opt/security.sh
ls -la /bin/bash
bash -p
cat /root/root.txt
find / -name "..."
```
Ahora hacemos un sudo -l donde vemos que es posible escalar privilegios con el fichero security.sh![[Pasted image 20240305230308.png]]
Vemos el script de security.sh y debido a como es intentamos hacer un path hijacking![[Pasted image 20240305230941.png]]
En este caso crearemos un script de tr que sustituiremos por el read del script
![[Pasted image 20240305231006.png]]
Entonces ejecutaremos el script pero teniendo como ruta inicial el directorio tmp y lograremos poner permisos de root a bash![[Pasted image 20240305232900.png]]
Ejecutamos la bash y finalmente somos usuario root
![[Pasted image 20240305232959.png]]
Buscamos la flag pero nos encontramos el siguiente problema![[Pasted image 20240305233040.png]]
Encontramos el archivo pero esta codificado
![[Pasted image 20240305233225.png]]
Probamos a usar el security.sh para decodificar la flag pero nos dice que no puede ser mas de 20 caracteres así que eliminamos la limitación y obtenemos la flag de root![[Pasted image 20240305233522.png]]

Flag de user: ab0366431e2d8ff563cf34272e3d14bd
Flag de root: 98199a723d0f44f6ef39e33685d8cabd