
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.35 -oN escaneo
gobuster dir -u http://10.0.2.35/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
wget http://10.0.2.35/relax.wav
wget http://10.0.2.35/screen-1.jpg
wget http://10.0.2.35/yay/mysecretsound.wav
ssh paul@10.0.2.35
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 22 y 80.
![[Pasted image 20240312152720.png]]
Entramos en el servicio web y encontramos un audio y una imagen que nos descargaremos en la maquina local para ver si hay archivos ocultos.
![[Pasted image 20240312153142.png]]
![[Pasted image 20240312153117.png]]
Mirando el codigo fuente de la web encontramos el usuario paul y una carpeta a la que hacemos fuzzing pero no encontramos nada, además si nos metemos en boootstrap.min.css encontramos esta directorio /yay/mysecretsound.wav![[Pasted image 20240312154545.png]]
Ahora nos descargamos el audio del directorio yay.
![[Pasted image 20240312155007.png]]
Al entrar en yay vemos un error 403 que no nos deja entrar al directorio, así que intentaremos encontrar un usuario y contraseña en los archivos que nos proporciona la web, en la imagen no encontramos nada usando stegcrack así que probamos con los audios así que analizamos su espectro con la web https://morsecode.world/international/decoder/audio-decoder-adaptive.html y vemos la posible contraseña dancingpassyo.
![[Pasted image 20240312155618.png]]
Ahora entramos por ssh con las credenciales anteriores y sacamos la flag de user.
![[Pasted image 20240312155736.png]]
```bash
cat user.txt
sudo -l
sudo ln -fs /bin/sh /bin/ln
sudo ln
cat /root/root.txt
```
Ahora usamos el sudo -l para ver binarios con permisos sudo y encontramos el binario ln, así que buscamos un exploit en gtfobins y lo ejecutamos consiguiendo así el usuario root y en consecuencia su flag.
![[Pasted image 20240312160100.png]]


Flag de user: ilovetoberelaxed
Flag de root: ilovetoberoot