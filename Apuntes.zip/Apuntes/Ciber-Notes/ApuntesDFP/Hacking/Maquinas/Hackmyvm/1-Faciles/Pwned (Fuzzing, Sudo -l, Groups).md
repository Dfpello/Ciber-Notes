```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.25 -oN escaneo
gobuster dir -u http://10.0.2.25/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
wget http://10.0.2.25/hidden_text/secret.dic
gobuster dir -u http://10.0.2.25/ -w /home/kali/Documents/HackMyVM/Pwned/secret.dic
ftp 10.0.2.25
cat note.txt
chmod 600 id_rsa
ssh ariana@10.0.2.25 -i id_rsa
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos donde vemos que tiene los puertos 21, 22 y 80 abiertos.
![[Pasted image 20240310012013.png]]
Hacemos fuzzing web con gobuster y encontramos el directorio nothing y el directorio hidden_text.
![[Pasted image 20240310012447.png]]
El direcotirio nothing nos lleva a un html que no tiene nada en la web y en el código fuente
![[Pasted image 20240310012612.png]]
En el directorio hidden_text encontramos un diccionario el cual nos descargaremos para ver hacer fuzzing con ese diccionario y encontramos un directorio.
![[Pasted image 20240310013243.png]]
Vemos la siguiente web.
![[Pasted image 20240310013312.png]]
Pero en el codigo fuente nos encontramos un usuario y una contraseña.
![[Pasted image 20240310013341.png]]
Debido a que el usuario es ftpuser:B0ss_B!TcH intentamos logarnos por ftp lo cual logramos y nos metemos dentro del directorio share y nos descargamos los dos archivos.
```ftp
cd share
get id_rsa
get note.txt
```
![[Pasted image 20240310013718.png]]
Ahora abrimos la nota y deducimos que puede existir un usuario ariana debido a que en el mensaje de la web inicial decía que ELLA canta muy bien.![[Pasted image 20240310013853.png]]
Así que le damos permisos a id_rsa e iniciamos sesion por ssh como el usuario ariana
```bash
cat user1.txt
cat /home/messenger.sh
cd ..
sudo -u selena ./messenger.sh
```
![[Pasted image 20240310014200.png]]
Conseguimos la flag de user.
![[Pasted image 20240310014229.png]]
Hacemos un sudo -l y vemos que tenemos permisos sudo en el archivo messenger.sh así que abrimos el archivo messengers.sh y encontramos el siguiente script
![[Pasted image 20240310014606.png]]
Entonces ejecutamos el /bin/bash en vez de un mensaje y logramos una shell como selena
![[Pasted image 20240310015251.png]]
```bash
script /dev/null -c bash
id
docker run -v /:/mnt --rm -it alpine chroot /mnt sh
script /dev/null -c bash
cat /root/root.txt
```
Ahora encontramos la flag de selena
![[Pasted image 20240310015510.png]]

Vemos que selena pertenece al grupo docker
![[Pasted image 20240310020533.png]]
Así que buscamos un exploit en gtfobins y usandolo escalamos privilegios para ser usuario root y encontramos la flag de root.
![[Pasted image 20240310020834.png]]



Flag de user: fb8d98be1265dd88bac522e1b2182140
Flag de root: 4d4098d64e163d2726959455d046fd7c