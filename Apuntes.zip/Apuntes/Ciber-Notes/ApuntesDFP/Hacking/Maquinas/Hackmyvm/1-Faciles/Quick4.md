
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.31 -oN escaneo
gobuster dir -u http://10.0.2.32/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
cat .secretnote.txt
knock 10.0.2.29 1000 2000 3000
```

Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos donde vemos que tiene los puerto 22 y 80 abiertos.