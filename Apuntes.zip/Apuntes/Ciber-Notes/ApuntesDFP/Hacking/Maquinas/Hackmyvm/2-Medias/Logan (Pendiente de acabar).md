
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.13 -oN escaneo
nano /etc/host
wfuzz -c --hc=404 -w /usr/share/wordlists/dirbuster/directory-list-lowercase-2.3-medium.txt -H "Host: FUZZ.logan.hmv" -u 10.0.2.13
wfuzz -c --hc=404 --hl=1 -w /usr/share/wordlists/dirbuster/directory-list-lowercase-2.3-medium.txt -H "Host: FUZZ.logan.hmv" -u 10.0.2.13
```
Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos
![[Pasted image 20240302225807.png]]Encontramos los puertos 25 y 80 abiertos así que procedemos a ver el servicio web que corre la máquina
![[Pasted image 20240302230021.png]]
Al entrar en la servicio web mediante la ip nos redirige a logan.hmv
![[Pasted image 20240302230240.png]]
Así que debido a esto se está aplicando un servicio de virtual hosting así que procedemos a editar el /etc/host
![[Pasted image 20240302230635.png]]
Ahora buscaremos subdominios usando el dns con wfuzz![[Pasted image 20240302231052.png]]
Debido a que hay muchas respuestas filtraremos que el código sea 1 ![[Pasted image 20240302231233.png]]
Esto encontrará la pagina admin.logan.hmv![[Pasted image 20240302231306.png]]