
**Misión 1**
```shell
ls -la
cat .myhiddenpazz
su sophia
cd ../sophia
cat flagz.txt
```
user: sophia
pass: Y1o645M3mR84ejc
flag: 8===LUzzNuv8NB59iztWUIQS===D~~

**Misión 2**
```shell
find / -name 'whereismypazz.txt' 2>/dev/null
cat /usr/share/whereismypazz.txt
cd ../angela
cat flagz.txt
```
user: angela 
pass: oh5p9gAABugHBje
flag: 8===SjMYBmMh4bk49TKq7PM8===D~~

**Misión 3**
```shell
head -4069 findme.txt | tail -n 1
su emma
cd ../emma
cat flagz.txt
```
user: emma
pass: fIvltaGaq0OUH8O
flag: 8===0daqdDlmd9XogkiHu4yq===D~~

**Misión 4**
```shell
cat ./-
su mia
cd ../mia
cat flagz.txt
```
user: mia
pass: iKXIYg0pyEH2Hos
flag: 8===FBMdY8hel2VMA3BaYJin===D~~

**Misión 5**
```shell
find / -name 'hereiam' 2>/dev/null
cat /opt/hereiam/.here
su camila
cd ../camila
cat flagz.txt
```
user: camila
pass: F67aDmCAAgOOaOc
flag: 8===iDIi5sm1mDuqGmU5Psx6===D~~

**Misión 6**
```shell
find / -name 'muack' 2>/dev/null
cat ./muack/111/111/muack
su luna
cd ../luna
cat flagz.txt
```
user: luna
pass: j3vkuoKQwvbhkMc
flag: 8===KCO34FpIq3nBmHbyZvFh===D~~

**Misión 7**
```shell
find / -size 6969c 2>/dev/null
cat /usr/share/moon.txt
su eleanor
cd ../eleanor
cat flagz.txt
```
user: eleanor
pass: UNDchvln6Bmtu7b
flag: 8===Iq5vbyiQl4ipNrLDArjD===D~~

**Misión 8**
```shell
find / -user violin 2>/dev/null
cat /usr/local/games/yo
su victoria
cd ../victoria
cat flagz.txt
```
user: victoria
pass: pz8OqvJBFxH0cSj
flag: 8===NWyTFi9LLqVsZ4OnuZYN===D~~

**Misión 9**
```shell
find / -name '*.zip' 2>/dev/null
cd /tmp
unzip /var/tmp/k/passw0rd.zip
cat passw0rd.txt
su isla
cd ../isla
cat flagz.txt
```
user: isla
pass: D3XTob0FUImsoBb
flag: 8===ZyZqc1suvGe4QlkZHFlq===D~~

**Misión 10**
```shell
cat passy | grep '$a9HFX'
su violet
cd ../violet
cat flagz.txt
```
user: violet
pass: WKINVzNQLKLDVAc
flag: 8===LzErk0qFPYJj16mNnnYZ===D~~

**Misión 11**
```shell
cat end | grep '0JuAZ$'
su lucy
cd ../lucy
cat flagz.txt
```
user: lucy
pass: OCmMUjebG53giud
flag: 8===AdCJ4wl8pmbhi770Xbd3===D~~

**Misión 12**
```shell
grep 'fu' file.yo | grep 'ck'
cat file.yo | grep -oP 'fu.*?ck'
su elena
cd ../elena
cat flagz.txt
```
user: elena
pass: 4xZ5lIKYmfPLg9t
flag: 8===st1pTdqEQ0bvrJfWGwLA===D~~

**Misión 13**
```shell
env
su alice
cd ../alice
cat flagz.txt
```
user: alice
pass: Cgecy2MY2MWbaqt
flag: 8===st1pTdqEQ0bvrJfWGwLA===D~~

**Misión 14**
```shell
cat /etc/passwd | awk '{print $5}' FS=':' | strings
su anna
cd ../anna
cat flagz.txt
```
user: anna
pass: w8NvY27qkpdePox
flag: 8===5Y3DhT66fa6Da8RpLKG0===D~~

**Misión 15**
```shell
sudo -u natalia /bin/bash
cd ../natalia
cat flagz.txt
```
user: natalia
flag: 8===5Y3DhT66fa6Da8RpLKG0===D~~

**Misión 16**
```shell
cat base64.txt | base64 -d
su eva
cd ../eva
cat flagz.txt
```
user: eva
pass: upsCA3UFu10fDAO
flag: 8===22cqk3iGkGYVqnYrHiof===D~~

**Misión 16**
```shell
find / -mtime +18000 2>/dev/null
cat /usr/lib/cmdo
su clara
cd ../clara
cat flagz.txt
```
user: clara
pass: 39YziWp5gSvgQN9
flag: 8===EJWmHDEQeEN1vIR7NYiH===D~~
