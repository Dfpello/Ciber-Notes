
**Datos Ocultos**
Se obtienen mediante comandos como:

`https://insecure-website.com/products?category=Gifts'-- -`

`https://insecure-website.com/products?category=Gifts'+OR+1=1-- -`

**Debilidad en los usuarios:**
Escribiendo lo siguiente en el recuadro de usuarios `administrator'--`

[Payloads](https://portswigger.net/web-security/sql-injection/cheat-sheet)