Ejercicio 1
```bash
echo 'VEhNe2p1NTdfZDNjMGQzXzdoM19iNDUzfQ==' | base64 -d
```
![[Pasted image 20231123003642.png]]
Ejercicio 2
```bash
exiftool Findme.jpg
```
![[Pasted image 20231123004122.png]]
Ejercicio 3
```bash
steghide extract -sf Extinction.jpg
```
![[Pasted image 20231123004257.png]]
Ejercicio 4
![[Pasted image 20231123004450.png]]
Ejercicio 5
Simplemente escaneamos el QR y obtenemos la flag THM{qr_m4k3_l1f3_345y}

Ejercicio 6
```bash
strings hello.hello | grep 'THM'
```
![[Pasted image 20231123005200.png]]
Ejercicio 7 
```bash
echo '3agrSy1CewF9v8ukcSkPSYm3oKUoByUpKG4L' | base58 -d
```
![[Pasted image 20231123005658.png]]
Ejercicio 8
Usamos el cifrado cesar
![[Pasted image 20231123010129.png]]
Ejercicio 9
Miramos el codigo html
![[Pasted image 20231123010501.png]]
Ejercicio 10
```bash
echo '3agrSy1CewF9v8ukcSkPSYm3oKUoByUpKG4L' | base58 -d
```