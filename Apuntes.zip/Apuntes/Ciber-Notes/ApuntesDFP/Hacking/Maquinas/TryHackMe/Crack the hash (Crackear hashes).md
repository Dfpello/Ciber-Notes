
1- MD5
```bash
hashcat -m 0 -a 0 Ej1.txt /usr/share/wordlists/rockyou.txt
```
![[Pasted image 20231116141535.png]]
2- SHA1
```bash
hashcat -m 100 -a 0 Ej2.txt /usr/share/wordlists/rockyou.txt
```
![[Pasted image 20231116141917.png]]
3- SHA-256
```bash
hashcat -m 1400 -a 0 Ej3.txt /usr/share/wordlists/rockyou.txt
```
![[Pasted image 20231116142156.png]]
4- bcrypt hash
```bash
hashcat -m 3200 -a 3 Ej4.txt ?l?l?l?l #Usamos esto debido a que sino es demasiado lento
```

5- MD4
```bash
hashcat -m 900 -a 0 Ej5.txt /usr/share/wordlists/rockyou.txt
```

6-SHA-256
```bash
hashcat -m 1400 -a 0 Ej6.txt /usr/share/wordlists/rockyou.txt
```
![[Pasted image 20231116155344.png]]
7-NTLM
```bash
hashcat -m 1000 -a 0 Ej7.txt /usr/share/wordlists/rockyou.txt
```
![[Pasted image 20231116155307.png]]
8-SHA-512 con salt = aReallyHardSalt
```bash
hashcat -m 1800 -a 0 Ej8.txt /usr/share/wordlists/rockyou.txt
```

9-HMAC-SHA1 con salt = tryhackme
```bash
hashcat -m 110 -a 0 Ej9.txt /usr/share/wordlists/rockyou.txt
```

