
```bash
#!/bin/bash
ping 10.10.255.186 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sC -sV --min-rate 5000 -n -vvv -Pn 10.10.255.186 -oN escaneo 
#Vemos los puertos 22 y 80 abiertos y procedemos a hacer fuzzing web con gobuster para ver los directorios de esta
nikto -h 10.10.255.186 #Para encontrar el login.php
gobuster dir -u http://10.10.255.186/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
```
nmap![[Pasted image 20231121213654.png]]