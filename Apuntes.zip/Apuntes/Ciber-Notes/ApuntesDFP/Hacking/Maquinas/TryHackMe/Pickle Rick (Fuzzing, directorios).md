
```bash
#!/bin/bash
ping 10.10.156.210 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sV --min-rate 5000 -n -vvv -Pn 10.10.156.210 -oN escaneo 
#Vemos los puertos 20 y 80 abiertos y procedemos a hacer fuzzing web con gobuster para ver los directorios de esta
nikto -h 10.10.156.210 #Para encontrar el login.php
gobuster dir -u http://10.10.156.210/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
#Encontramos multiples directorios entre ellos un login.php y robots.txt donde obtenemos lo que parece ser una contraseña
curl http://10.10.156.210/ #Obtenemos un usuarios en los comentarios del codigo
#Una vez echo esto nos loggeamos en la maquina objetivo en el login.php llegando a un menu en el que podemos ejecutar comandos y ejecutando el comando ls podemos ver la primera flag
#Una vez dentro ejecutamos el comando que vemos en la segunda imagen para obtener la segunda flag que buscamos anteriormente por el sistema de archivos
sudo -l #Vemos que permisos tenemos de superusuario y una vez visto que podemos hacer lo que queramos ejecutamos el comando de la tercera imagen para conseguir la ultima flag
```
Primer ingrediente![[Pasted image 20231114164903.png]]Segundo ingrediente![[Pasted image 20231114170338.png]]Tercer ingrediente![[Pasted image 20231114170713.png]]