
Esta CTF esta orientada hacia la criptografía iré resolviendo los apartados en orden detallando el método a utilizar
1- Convertimos las letras a los números mas similares, se trata de una sustitución simple
2- Pasamos de binario a código ASCII en un conversor online
3- Vemos que esta codificado en base32 y usamos el siguiente comando en Kali
![[Pasted image 20231116131352.png]]4- Vemos que esta en base64 y usamos el siguiente comando en Kali
![[Pasted image 20231116131609.png]]5- Usamos un conversor de hexadecimal a ASCII
6- Usamos un conversor cesar con una rotación de 13 posiciones
7- Investigando vemos que es un rot-47 y lo desciframos en su conversor
8- Usamos un conversor de morse a texto
9- Hay que pasar de base10 a ASCII
10- Tenemos primero que convertirlo de base64, que nos dará un morse que tenemos que descifrar, este a su vez nos dará un binario que al pasarlo a ASCII no dará un rot47 que nos dará un base10 y finalmente este nos dará el código final 

2-Espectograma: Usamos la herramienta wavepad y lo desciframos sin problemas

3-Esteganografía: Usamos los siguientes comandos en Kali
![[Pasted image 20231116134319.png]]

4-Primero intentamos esteganografía pero vemos que nos da error entonces procedemos ha hacer un strings meme.jpg y encontramos el fichero hackerchat.png y el texto AHH_YOU_FOUND_ME!