
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.11 -oN escaneo
#Pendiente el fuzzing
hydra -t 64 -l admin -P /usr/share/wordlists/rockyou.txt 10.0.2.11 http-post-form "/my_weblog/admin.php:username=admin&password=^PASS^:Incorrect username or password."
```
Primero de todo realizmaos un arp-scan para encontrar la ip y una vez tengamos su IP realizamos un nmap![[Pasted image 20240301133947.png]]
Con el cual encontramos los puertos 22 y 80 abiertos![[Pasted image 20240301134040.png]]
Por ende vamos a vez la pagina web donde encontramos la siguiente pagina![[Pasted image 20240301134135.png]]
Así que miro el código fuente de la página pero tampoco hay nada nuevo, viendo esto hacemos fuzzing  a la dirección

Mediante el fuzzing encontramos el siguiente panel de login en la siguiente dirección:
http://10.0.2.11/my_weblog/admin.php ![[Pasted image 20240301134418.png]]
El cual procederemos a ver si podemos encontrar el usuario admin que es el más típico y hacer un ataque de fuerza bruta hacia el usuario, pero primero tenemos que conseguir la dirección exacta del usuario y contraseña para lo cual usaremos burp suite e interceptamos la siguiente petición
![[Pasted image 20240301134809.png]]
Una vez tenemos los datos de burpsuite y el mensaje de error ejecutamos hydra para atacar mediante fuerza bruta a la web![[Pasted image 20240301135404.png]]
Tras esperar un rato conseguiremos la contraseña que es kisses![[Pasted image 20240301135502.png]]