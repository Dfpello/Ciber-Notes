
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.18 -oN escaneo
nmap -sU --top-ports 200 --min-rate=5000 -Pn 10.0.2.21
onesixtyone -c /usr/share/wordlists/rockyou.txt 10.0.2.21
snmpwalk -v 2c -c security 10.0.2.21
nano /etc/hosts
wfuzz -c --hc=404 --hl=11 -w /usr/share/amass/wordlists/subdomains-top1mil-20000.txt -H "Host: FUZZ.chaincorp.nyx" -u 10.0.2.21
nano /etc/hosts
```
Primero realizamos el scaneo con nmap que no nos lleva a ningun lado así que procedemos a hacer un escaneo por UDP que nos devuelve los siguientes puertos pero nos fijamos en el puerto 161 que está abierto con el protocolo snmp![[Pasted image 20240307230931.png]]
Ahora usaremos la herramienta de onesixtyone para que nos encuentre la clave de comunidad que nos permitirá seguir enumerando este protocolo![[Pasted image 20240307231332.png]]
Ahora con la clave de seguridad security usamos snmpwalk para que nos enumere información
![[Pasted image 20240307231432.png]]
Como dato relevante encontramos un dominio y un posible usuario con blue@chaincorp.nyx entonces ahora hacemos fuzzing de subdominios con wfuzz y encontramos el dominio utils.chaincorp.nyx ![[Pasted image 20240307232037.png]]
Entramos en el subdominio utils y encontramos el siguiente panel
![[Pasted image 20240307232154.png]]
Metiendonos en los links vemos que se ejecutan distintos php que da a pensar que se puede hacer un local file inclusion, entonces buscamos en el archivo /etc/passwd usuarios y encuentro los usuarios blue y red.
