
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.14 -oN escaneo
nano /etc/hosts
dig axfr hunterzone.nyx @10.0.2.14
wfuzz -c --hc=404 --hl=367 -w /usr/share/amass/wordlists/subdomains-top1mil-20000.txt -H "Host: FUZZ.devhunter.nyx" -u 10.0.2.14
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap![[Pasted image 20240303005928.png]]
Vemos que están abiertos los puertos 22, 53, 80![[Pasted image 20240303010023.png]]
Vemos el dominio hunterzone.nyx y lo añadimos al /etc/hosts
![[Pasted image 20240303010218.png]]
A continuación dado que tenemos también corriendo un servicio DNS  realizaremos un ataque de transferencia de zona DNS y nos centraremos en el subdominio devhunter.nyx![[Pasted image 20240303011009.png]]
Aplicaremos un limite a las lineas para que sea 367 y así se muestren unicamente los ficheros mas interesantes![[Pasted image 20240303011625.png]]
Ahora añadimos el subdominio files.devhunter.nyx y entramos a la web donde vemos el siguiente formato para añadir ficheros![[Pasted image 20240303012012.png]]
