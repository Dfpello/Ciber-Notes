
Distintos comandos utilizados por mi en scripts
```bash
#!/bin/bash
cat hola.txt #Devuelve el texto de hola.txt
grep hola #filtra todo loi que contiene hola
wc -c -l #Devuelve el numero de caracteres y el numero de lineas
cat jaja.txt 2>/dev/null #Redirige los errores a dev null
cat jaja.txt >/dev/null #Redirige la solucion a dev null
awk '/hola/' jaja.txt | awk '{print $2}' #La primera parte devuelve la fila filtrada por hola en jaja.txt y la segunda parte devuelve el segundo argumento de una fila como resultado final
cat jaja.txt | awk 'NF{print $NF}' #Devuelve el último elemento de la fila
sort #Ordena las cadenas alfabeticamente
strings data.txt #Devuelve el texto legible de data.txt
uniq -u #Devuelve si la fila solo aparece una vez
uniq  #Devuelve una fila de cada repeticion
cat data.txt | base64 #Devuelve el archivo codificado en base 64
cat data.txt | base64 -d #Devuelve el archivo codificado en base 64
cat data.txt | tr '[G-ZA-Fg-za-f]' '[T-ZA-St-za-s]' #Realiza una rotacion de caracteres de 13 posiciones
7z l data.gzip #Lista el resultado si descomprimes el archivo
7z x data.gzip #Descomprime el archivo data.gzip
tail -n 1 #Muestra las filas empezando por el final dependiendo del numero pasado
telnet host puerto #Sirve para conectarse al puerto de un host
diff fich1 fich2 #Muestra las diferencias entre dos ficheros
ss #Devuelve todos los contenidos conectados a la maquina analizada
```