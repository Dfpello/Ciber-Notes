
```bash
#!/bin/bash
file data #Devuelve el tipo de archivo que es
```
