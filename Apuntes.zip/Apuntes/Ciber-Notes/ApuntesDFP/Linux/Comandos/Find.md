
Aquí observaremos las diferentes etiquetas y utilidades del comando find en bash el cual devuelve todos los archivos que encuentra
Usados:
```bash
#!/bin/bash
find -type f #Devuelve solo archivos
find -readable -executable -writable #Mira si el archivo es legible, ejecutable y escribible
find -size 1000c #Coge los archivos con 1000 bytes
find -name n* #Coge los archivos que empiezan por n (tambien se puede quitar el astelisco)
find -group root #Busca los grupos que son owner
find -user root #Busca los archivos que son del usuario root
```
