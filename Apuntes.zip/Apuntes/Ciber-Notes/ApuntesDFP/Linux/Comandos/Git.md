
```bash
#!/bin/bash
git clone #Clona un repositorio
git log #Muestra los cambios de un repositorio con -p o -t
git branch -r #Muestra las ramas del repositorio
git checkout rama #Se mueve el git a otra rama
git tag #Muestra las etiquetas
git show etiqueta #Muestra el contenido de la etiqueta seleccionada
git add fichero #Para añadir un fichero
git commit -m "" #Para comentar la modificacion

```
