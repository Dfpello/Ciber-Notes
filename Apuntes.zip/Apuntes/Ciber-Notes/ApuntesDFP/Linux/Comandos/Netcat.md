Herramienta de red que permite la lectura y escritura de datos a través de conexiones de red utilizando distintos protocolos puede actuar tanto de cliente como servidor esto se usa principalmente para enviar reverse shells a tu máquina atacante
```bash
#!/bin/bash
nc host puerto #Para conectarte al host con el puerto
nc -nlvp 443 #Ponemos en escucha el puerto 443
```