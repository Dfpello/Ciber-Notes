Es una herramienta que proporciona herramientas criptograficas como el protocolo SSL/TLS entre otras cosas
```bash
#!/bin/bash
openssl s_client -connect localhost:20 #Nos conectamos usando encriptacion ssl
```