
El comando se usa para entrar en el servicio smb
```bash
#!/bin/bash
smbclient -N -L -U user \\\\10.129.42.253
```
