
El comando se usa para 
Aquí observaremos las diferentes etiquetas y utilidades del comando ssh en bash
Importantes:
```bash
#!/bin/bash
ssh -p puerto usuario@servidor#Especifica el puerto al que conectarse desde ssh
ssh -l usuario servidor#Para especificar el usuario
ssh -i sshkey.private usuario@servidor#Permite usar un archivo de clave como autentificacion
ssh -X #Habilita X11 permitiendo ejecutar aplicaciones gráficas en el servidor remoto y visualizarlas en el cliente local
ssh -L 8080:localhost:80 servidor#Establece un renvio al puerto local
ssh -R #Establece un reenvío de puerto remoto
ssh -C #Habilita la compresión de datos durante la transferencia
ssh servidor bash #El comando bash se usa para meterte en una consola antes de entrar a la pantalla del servidor
```
