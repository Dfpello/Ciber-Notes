```bash
read -p "txt" var #Para introducir un input y lo guardamos en la variable var
ping $ip #Realiza un ping a la ip para ver si esta operativa
echo "hola" #Escribe en linea de comandos
#Estructura if-else
if []; then
else
fi

```