Los sockets en Python permiten la comunicación entre procesos en una red utilizando el protocolo TCP/IP o UDP. Con los sockets, se pueden crear programas que envían y reciben datos en tiempo real a través de una red.

[Tutorial extenso](https://realpython.com/python-sockets/)

```python
import sockets
#Para crear un socket con trasporte TCP(AF_INET) y que usa IPv4 (SOCK_STREAM) usamos
client, server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#Para conectar un cliente usamos
client.connect((target_host, target_port))
#Para enviar datos tenemos que ponerlos en formato byte si no lo estan mediante el siguiente codigo siendo el request los datos a enviar y el encode el decodificador
client.send(request.encode("utf-8"))
#Para recibir los datos usamos el .recv(numero de bytes) y decodificamos el mensaje si es necesario
response = client.recv(4096).decode("utf-8")
#Para conectar un servidor usamos
server.bind((bind_ip,bind_port))
#Luego en el sevidor vemos cuantas entradas puede leer con 
server.listen(5) #Lee 5 
#Posteriormente aceptaremos las conexiones mediante 
client,addr = server.accept()
```
