
**Cliente TCP**
```python
import socket #Importamos la librería socket

#Nombre del host objetivo
target_host = "www.google.com"
#target_host = "0.0.0.0"
#Puerto al que nos queremos conectar
target_port = 80 #80 corresponde al puerto TCP

#creamos un objeto de socket llamos client
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
#AF_INET indica el uso de IPv4 y SOCK_STREAM indica que se utilizara el protocolo de transporte TCP

#Conectamos el cliente
client.connect((target_host,target_port))

#Enviar datos
request = "GET /HTTP/1.1\r\nHost: google.com\r\n\r\n"
client.send(request.encode("utf-8"))

#Recibir datos
response = client.recv(4096).decode("utf-8")

#Printea los datos por consola
print (response)
```
**Servidor TCP
```python
import socket
import threading

bind_ip = "0.0.0.0"
bind_port = 9999

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#Pasamos la ip y puerto para la escucha
server.bind((bind_ip,bind_port))

#El servidor escucha con un backlog connections de 5
server.listen(5)

print ("[*] Listening on {}:{}".format(bind_ip,bind_port))

#Este es nuestro hilo de cliente que manejara las conexiones de los clientes
def handle_client(client_socket):

    #Devolvemos lo que el cliente envia
    request = client_socket.recv(1024)

    print ("[*] Received: {}".format(request))
    
    #Envia de vuelta el paquete
    req = "ACK!"
    client_socket.send(req.encode("utf-8"))

    client_socket.close()

while True:
    #El servidor acepta conexiones entranres y bloquea la ejecucion del programa hasta que se establezca una conexion
    client,addr = server.accept()
    print ("[*] Accepted connection from: {}:{}".format(addr[0],addr[1]))

    #Crea un ihlo que ejecutara la funcion handle_client y manejara los datos del cliente
    client_handler = threading.Thread(target=handle_client,args=(client,))
    client_handler.start()
```
