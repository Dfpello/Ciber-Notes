
**Cliente UDP
```python
import socket #Importamos la librería socket

#Nombre del host objetivo
target_host = "127.0.0.1"
#Puerto al que nos queremos conectar
target_port = 80 #80 corresponde al puerto de ataque

#creamos un objeto de socket llamos client
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#AF_INET indica el uso de IPv4 y SOCK_DGRAM indica que se utilizara el protocolo de transporte UDP

#Enviar datos
request = "AAABBBCCC"
client.sendto(request.encode("utf-8"), (target_host,target_port))

#Recibir datos
data, addr = client.recvfrom(4096)
response = data.decode("utf-8")

#Printea los datos por consola
print (response)
```
