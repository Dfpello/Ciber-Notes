
Aquí encontramos los comandos utilizados junto con sus usos
```python
import sys
#Para finalizar el programa y volver al sistema operativo
#Utiliamos sys.exit(0) indicando el 0 que la salida fue exitosa
sys.exit(0)
#Similar a java se usa para coger el primer argumento de despues del codigo de la ejcucion
sys.argv[1]
#Variante que coge todos los elementos del codigo
sys.argv[1:]
#Para leer elementos usamos el stdin
sys.stdin.read()
```
