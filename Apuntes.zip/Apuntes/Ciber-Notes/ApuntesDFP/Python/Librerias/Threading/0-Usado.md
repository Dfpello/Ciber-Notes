Esta herramienta sirve para usar la concurrencia y tener varios procesos al mismo tiempo
```python 
import threading
#Usamos el siguiente codigo para crear hilos siendo target la funcion deseada y args sus argumentos
proxy_thread = threading.Thread(target=proxy_handler, args=(client_socket, remote_host, remote_port, receive_first))
#Este codigo se usa para empezar el hilo creado
proxy_thread.start()
```
